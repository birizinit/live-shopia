// PONTE entre o chat da página (content.js) e o motor de IA (motor-ia.js).
// O side panel NÃO enxerga o DOM da live; então o content.js lê o chat e manda
// cada comentário/entrada pra cá via chrome.runtime. Aqui a gente liga o LFMotor
// (voz no cabo) e repassa os eventos. Script LIMPO (o sidebar.js é ofuscado).
(function (g) {
  'use strict';

  const M = () => g.LFMotor;
  const P = () => g.LFPainel;
  let ativo = false;
  let desassinar = null;
  const ouvintesStatus = new Set();
  function status(ev) { for (const fn of ouvintesStatus) { try { fn(ev); } catch (e) {} } }

  // ---- recebe o chat lido na página ----
  if (g.chrome && g.chrome.runtime && g.chrome.runtime.onMessage) {
    g.chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || !ativo || !M()) return;
      try {
        if (msg.action === 'liveComment') M().aoComentar(msg.nome || 'amor', msg.texto || '');
        else if (msg.action === 'liveEntry') M().aoEntrar(msg.nome || 'amor');
      } catch (e) {}
    });
  }

  // ---- manda o content.js começar/parar de ler o chat na(s) aba(s) da TikTok ----
  function avisarAbas(action) {
    try {
      g.chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        if (g.chrome.runtime.lastError) return;
        (tabs || []).forEach((t) => {
          try { g.chrome.tabs.sendMessage(t.id, { action }, () => { if (g.chrome.runtime.lastError) {} }); } catch (e) {}
        });
      });
    } catch (e) {}
  }

  async function contaTikTok() {
    try { const d = await P().contas(); return (d.contas && d.contas[0] && d.contas[0].tiktok_user) || undefined; }
    catch (e) { return undefined; }
  }

  const API = {
    estaAtivo: () => ativo,
    aoStatus(fn) { ouvintesStatus.add(fn); return () => ouvintesStatus.delete(fn); },

    // Liga a live: autoriza no painel (gate), começa a ler o chat e a falar.
    async ativar() {
      if (ativo) return { ok: true, jaAtivo: true };
      if (!M() || !P()) { status({ tipo: 'erro', texto: 'motor não carregado' }); return { ok: false, erro: 'motor indisponível' }; }
      if (!(await P().estaLogado())) { status({ tipo: 'erro', texto: 'faça login primeiro' }); return { ok: false, erro: 'login' }; }
      status({ tipo: 'sistema', texto: 'Iniciando respostas ao vivo…' });
      const conta = await contaTikTok();
      let r;
      try { r = await M().iniciar(conta); } catch (e) { status({ tipo: 'erro', texto: 'falha ao iniciar: ' + e.message }); return { ok: false, erro: e.message }; }
      if (!r || !r.ativo) { status({ tipo: 'erro', texto: 'não autorizado (' + ((r && r.motivo) || 'plano/limite') + ')' }); return { ok: false, erro: (r && r.motivo) || 'não autorizado' }; }
      ativo = true;
      desassinar = M().assinar((ev) => status(ev));
      avisarAbas('startChatWatch');
      status({ tipo: 'ativo', texto: 'Respostas ao vivo ATIVAS' });
      return { ok: true };
    },

    // Desliga: para de ler o chat, encerra a live e o heartbeat.
    async parar() {
      avisarAbas('stopChatWatch');
      try { if (M()) M().parar(); } catch (e) {}
      if (desassinar) { try { desassinar(); } catch (e) {} desassinar = null; }
      ativo = false;
      status({ tipo: 'parado', texto: 'Respostas ao vivo desligadas' });
      return { ok: true };
    },

    async toggle() { return ativo ? this.parar() : this.ativar(); },
  };

  g.LFBridge = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
