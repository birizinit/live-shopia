// Controlador de acesso da sidebar: tranca o app até o login no painel e
// exige autorização (gate paid-only + heartbeat) antes de iniciar a live.
// Usa o SDK LFPainel (painel.js). Arquivo separado do sidebar.js (que é o app).
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const overlay = () => $('accessScreen');
  let recheckTimer = null;

  // Estados do overlay: 'login' (deslogado), 'plano' (logado sem plano ativo), null (liberado).
  function estado(qual, info) {
    const o = overlay(); if (!o) return;
    const login = $('accessLoginBox'), plano = $('accessPlanBox');
    if (!qual) { o.style.display = 'none'; return; }
    o.style.display = 'flex';
    if (login) login.style.display = qual === 'login' ? 'block' : 'none';
    if (plano) plano.style.display = qual === 'plano' ? 'block' : 'none';
    if (qual === 'plano' && info) {
      const msg = $('accessPlanMsg'), det = $('accessPlanInfo'), btn = $('accessAssinar');
      if (msg) msg.textContent = info.nunca_assinou ? 'Você ainda não tem um plano ativo.'
        : (info.status === 'expirada' ? 'Seu plano venceu.' : (info.motivo || 'Assine para usar o Live Fox.'));
      if (det) det.textContent = info.plano_nome ? ('Plano: ' + info.plano_nome) : '';
      if (btn) btn.textContent = info.nunca_assinou ? 'Assinar plano' : 'Renovar plano';
    }
  }
  function mostrarLogin(v) { estado(v ? 'login' : null); }

  // Consulta a licença no servidor e (des)trava a UI. Liga um re-check periódico.
  async function checarLicenca() {
    let lic; try { lic = await LFPainel.licenca(); } catch { lic = { ativo: false, motivo: 'erro' }; }
    if (lic && lic.motivo === 'login') { pararRecheck(); estado('login'); return false; }
    if (lic && lic.ativo) { estado(null); ligarRecheck(); return true; }
    // logado, mas sem plano ativo → trava com opção de assinar; para a leitura da tela.
    try { window.LFLerTela && window.LFLerTela.parar(); } catch {}
    estado('plano', lic || {});
    ligarRecheck();
    return false;
  }
  function ligarRecheck() { if (recheckTimer) return; recheckTimer = setInterval(checarLicenca, 120000); if (recheckTimer.unref) recheckTimer.unref(); }
  function pararRecheck() { if (recheckTimer) { clearInterval(recheckTimer); recheckTimer = null; } }
  // Exposto pra ler-tela chamar quando o servidor mandar parar (assinatura caiu).
  window.LFAcesso = { rechecar: checarLicenca, travar: (info) => estado('plano', info || {}) };

  function toast(msg) {
    let t = $('lfToast');
    if (!t) {
      t = document.createElement('div'); t.id = 'lfToast';
      t.style.cssText = 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);' +
        'background:#0d1512;border:1px solid #8b5cf6;color:#eceaff;padding:10px 16px;border-radius:10px;' +
        'font:600 12px Inter,sans-serif;z-index:100000;max-width:90%;text-align:center;box-shadow:0 6px 20px rgba(0,0,0,.4)';
      document.body.appendChild(t);
    }
    t.textContent = msg; t.style.display = 'block';
    clearTimeout(t._h); t._h = setTimeout(() => { t.style.display = 'none'; }, 4000);
  }

  // ---- Login ----
  async function fazerLogin() {
    const usuario = ($('accessEmail')?.value || '').trim();
    const senha = $('accessSenha')?.value || '';
    const err = $('accessErr'), okd = $('accessOk'), btn = $('accessBtn');
    if (err) err.textContent = ''; if (okd) okd.textContent = '';
    if (!usuario || !senha) { if (err) err.textContent = 'Preencha usuário e senha.'; return; }
    if (btn) { btn.disabled = true; btn.textContent = 'Entrando…'; }
    const r = await LFPainel.login(usuario, senha);
    if (btn) { btn.disabled = false; btn.textContent = 'Entrar'; }
    if (!r.ok) { if (err) err.textContent = r.erro || 'Falha no login.'; return; }
    if (okd) okd.textContent = 'Bem-vindo!';
    await checarLicenca();   // logou: agora decide se libera ou trava por falta de plano
  }

  // ---- Gate do botão de iniciar/parar a live (#btnCiclo) ----
  let live = false;     // a IA já foi autorizada nesta sessão?
  let passar = false;   // deixa o clique "real" seguir pro handler original

  function instalarGate() {
    const btn = $('btnCiclo');
    if (!btn) return;
    btn.addEventListener('click', async (e) => {
      if (passar) { passar = false; return; }        // clique reencaminhado: segue normal
      e.preventDefault(); e.stopImmediatePropagation();

      if (live) {                                    // clicou pra PARAR
        live = false;
        try { await LFPainel.encerrarLive(); } catch {}
        passar = true; btn.click();                  // segue -> handler original encerra o ciclo
        return;
      }

      // clicou pra INICIAR -> precisa estar logado + autorizado
      if (!(await LFPainel.estaLogado())) { mostrarLogin(true); return; }
      btn.disabled = true;
      const r = await LFPainel.autorizarLive();
      btn.disabled = false;
      if (!r.ok) { toast('Live bloqueada: ' + (r.erro || 'não autorizado')); return; }
      toast(`Live liberada · plano ${r.plano} · ${Number(r.restante_horas).toFixed(1)}h`);
      live = true;
      passar = true; btn.click();                    // segue -> handler original inicia o ciclo
    }, true); // captura: roda ANTES do handler inline
  }

  // Se o servidor mandar parar (limite de horas / assinatura caiu), encerra a UI.
  function instalarOnParar() {
    LFPainel.onParar((motivo) => {
      if (!live) return;
      live = false;
      toast('Live encerrada: ' + motivo);
      const btn = $('btnCiclo');
      if (btn) { passar = true; btn.click(); }        // aciona o "parar" do handler original
    });
  }

  async function init() {
    if (typeof LFPainel === 'undefined') { console.error('[LiveFox] painel.js não carregou'); return; }
    $('accessBtn')?.addEventListener('click', fazerLogin);
    $('accessSenha')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') fazerLogin(); });
    // Botões da tela "sem plano": assinar abre o CHECKOUT NO APP (mesmo Simplify).
    $('accessAssinar')?.addEventListener('click', () => LFPainel.abrirCheckout());
    $('accessRecheck')?.addEventListener('click', (e) => { e.preventDefault(); checarLicenca(); });
    $('accessSair')?.addEventListener('click', async (e) => { e.preventDefault(); pararRecheck(); try { await LFPainel.logout(); } catch {} estado('login'); });
    // Boot: deslogado → login; logado → checa licença (libera ou trava por falta de plano).
    if (!(await LFPainel.estaLogado())) estado('login');
    else await checarLicenca();
    instalarGate();
    instalarOnParar();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
