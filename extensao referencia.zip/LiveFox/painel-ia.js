// UI do criador DENTRO da extensão: config (temas/roteiro), contas TikTok e planos.
// Usa o SDK LFPainel (painel.js) — mesmo login da extensão, sem duplo login.
(function () {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const el = (id) => document.getElementById(id);
  const P = () => window.LFPainel;
  let RECURSOS = {}, TEMAS = [], PLANOS = {}, PAG = null, POLL = null;

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const msg = (t, bad) => { const m = el('ia-msg'); if (m) { m.textContent = t || ''; m.style.color = bad ? '#fb7185' : '#8b5cf6'; } };

  // ---------- abrir / fechar / abas ----------
  function abrir() { el('iaPanel').style.display = 'block'; carregarConfig(); }
  function fechar() { el('iaPanel').style.display = 'none'; clearInterval(POLL); }
  function aba(nome) {
    document.querySelectorAll('#iaPanel .tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.iatab === nome));
    for (const t of ['config', 'contas', 'planos']) el('ia-' + t).style.display = t === nome ? 'block' : 'none';
    msg('');
    if (nome === 'contas') carregarContas();
    if (nome === 'planos') carregarPlanos();
  }

  // ---------- INÍCIO: créditos + "Ler a tela" (a extensão é só OUVIDOS) ----------
  async function carregarConfig() {
    let lic; try { lic = await P().licenca(); } catch (e) { lic = null; }
    if (lic && lic.motivo === 'login') return msg('Faça login primeiro.', true);
    const ativo = !!(lic && lic.ativo);
    const cr = Number(lic?.creditos_restantes || 0);
    const ct = Number(lic?.creditos_total || 0) + Number(lic?.creditos_comprados || 0);
    const usadoPct = ct > 0 ? Math.min(100, Math.round((1 - cr / ct) * 100)) : 0;
    const n = (x) => Number(x || 0).toLocaleString('pt-BR');

    el('ia-config').innerHTML = `
      <div class="slabel">Sua conta</div>
      <div class="card open"><div class="cb" style="display:flex">
        <div class="frow"><span class="fdesc">Plano</span>
          <b style="color:${ativo ? 'var(--green)' : 'var(--red)'}">${ativo ? esc(lic.plano_nome || lic.plano || 'ativo') : 'sem plano ativo'}</b></div>
        ${ativo && lic.dias_restantes != null ? `<div class="frow"><span class="fdesc">Dias restantes</span><b>${lic.dias_restantes}</b></div>` : ''}
        <div class="frow"><span class="fdesc">⚡ Créditos de IA</span><b style="color:var(--green)">${n(cr)}</b></div>
        <div style="height:7px;border-radius:99px;background:var(--bg);overflow:hidden;margin-top:2px"><div style="height:100%;width:${100 - usadoPct}%;background:var(--grad)"></div></div>
        <div style="font-size:9px;color:var(--muted)">${n(cr)} de ${n(ct)} disponíveis · gasta só quando a IA fala algo novo</div>
        ${ativo
          ? `<button class="btn bghost" id="ia-comprar" style="margin-top:6px">➕ Comprar créditos / gerenciar plano</button>`
          : `<button class="btn bgreen" id="ia-assinar" style="margin-top:6px">Assinar / Renovar no app</button>`}
      </div></div>

      <div class="slabel">Ler comentários da live</div>
      <div class="card open"><div class="cb" style="display:flex">
        <div style="font-size:10.5px;color:var(--muted);line-height:1.65">
          A extensão só <b>lê os comentários</b> da sua live e manda pro servidor.
          <b>Quem gera a voz e as respostas é o servidor</b> — a voz, o roteiro, os temas e os produtos você configura <b>no app</b>.
          <br><br>1️⃣ No <b>app</b>, clique <b>“Iniciar live”</b>.
          <br>2️⃣ Aqui, clique <b>“Ler a tela”</b>.
          <br>3️⃣ Deixe a <b>aba da live aberta</b> — é dela que a extensão lê o chat.
        </div>
        <button class="btn-main btn-start" id="ia-toggle-live" style="margin-top:8px">📖 Ler a tela</button>
        <div id="ia-live-status" style="font-size:11px;color:var(--muted);margin-top:4px">Desligado — clique pra começar a ler os comentários.</div>
        <button class="btn bghost" id="ia-abrir-app" style="margin-top:4px">⚙️ Configurar minha live no app</button>
      </div></div>`;

    if (el('ia-assinar')) el('ia-assinar').onclick = () => P().abrirCheckout();
    if (el('ia-comprar')) el('ia-comprar').onclick = () => P().abrirApp('perfil');
    if (el('ia-abrir-app')) el('ia-abrir-app').onclick = () => P().abrirApp('inicio');
    ligarRespostasAoVivo();
  }

  // ---------- Ler a tela (modo servidor-driven via LFLerTela) ----------
  function ligarRespostasAoVivo() {
    const btn = el('ia-toggle-live'), st = el('ia-live-status');
    if (!btn) return;
    if (!window.LFLerTela) { btn.disabled = true; if (st) st.textContent = 'Indisponível.'; return; }
    const pintar = () => {
      const on = window.LFLerTela.estaAtivo();
      btn.textContent = on ? '⏹️ Parar leitura' : '📖 Ler a tela';
      btn.style.opacity = '1';
    };
    pintar();
    window.LFLerTela.aoStatus((ev) => {
      if (!st || !ev) return;
      if (ev.tipo === 'lido') st.textContent = '👂 ' + (ev.lidos || 0) + ' lidos · último: ' + (ev.nome || '') + ': ' + String(ev.texto || '').slice(0, 24);
      else if (ev.texto) st.textContent = (window.LFLerTela.estaAtivo() ? '🟢 ' : '') + ev.texto;
      pintar();
    });
    btn.onclick = async () => {
      btn.disabled = true;
      const r = await window.LFLerTela.toggle();
      if (r && r.erro && st) st.textContent = 'Erro: ' + r.erro;
      btn.disabled = false;
      pintar();
    };
  }
  // ---------- CONTAS ----------
  async function carregarContas() {
    let d; try { d = await P().contas(); } catch { return msg('Faça login primeiro.', true); }
    el('ia-contas').innerHTML = `
      <div class="slabel">Contas TikTok (${d.contas.length}/${d.limite})</div>
      <div class="card open"><div class="cb" style="display:flex">
        ${d.contas.map((c) => `<div class="frow"><span class="fdesc">@${esc(c.tiktok_user)}</span><button class="btn bdanger" data-delc="${c.id}" style="flex:unset;padding:4px 10px;">Remover</button></div>`).join('') || '<div style="font-size:10px;color:var(--muted)">Nenhuma conta ainda.</div>'}
        ${d.contas.length < d.limite ? `<div style="display:flex;gap:6px;margin-top:6px;"><input type="text" id="ia-novaconta" placeholder="@suaconta" style="flex:1"><button class="btn bgreen" id="ia-addconta" style="flex:unset;padding:6px 12px;">Adicionar</button></div>`
        : `<div style="font-size:10px;color:#6366f1;margin-top:6px;">Limite do plano atingido. Faça upgrade pra adicionar mais contas.</div>`}
      </div></div>`;
    if (el('ia-addconta')) el('ia-addconta').onclick = async () => {
      const r = await P().addConta(el('ia-novaconta').value);
      if (r.ok) carregarContas(); else msg('Erro: ' + r.erro, true);
    };
    el('ia-contas').querySelectorAll('[data-delc]').forEach((b) => b.onclick = async () => { await P().delConta(b.dataset.delc); carregarContas(); });
  }

  // ---------- PLANOS / CHECKOUT ----------
  const DIAS = { 7: 'semana', 15: 'quinzena', 30: 'mês', 90: 'trimestre', 365: 'ano' };
  async function carregarPlanos() {
    try { PLANOS = await P().planos(); } catch { return msg('Faça login primeiro.', true); }
    const f = (on, t) => `<div style="font-size:10px;color:${on ? 'var(--text)' : 'var(--muted)'}">${on ? '✓' : '✕'} ${t}</div>`;
    el('ia-planos').innerHTML = `<div class="slabel">Escolha seu plano</div>
      <div style="font-size:10px;color:var(--muted);margin-bottom:6px">O pagamento (Pix) abre no app, já logado. A liberação é automática.</div>`
      + Object.values(PLANOS).map((p) => `
      <div class="card open"><div class="cb" style="display:flex">
        <div style="font-size:13px;font-weight:800;color:var(--text)">${esc(p.nome)}</div>
        <div style="font-size:20px;font-weight:800;color:#6366f1">R$ ${(+p.preco_brl).toLocaleString('pt-BR')} <span style="font-size:11px;color:var(--muted)">/ ${DIAS[p.dias] || p.dias + 'd'}</span></div>
        <div style="font-size:10px;color:var(--text)">⏱️ ${p.horas_mes >= 99999 ? '∞' : p.horas_mes}h · 📱 ${p.contas_tiktok} conta(s)</div>
        ${f(p.voz_premium, 'Voz premium')}${f(p.respostas_chat, 'Respostas no chat')}${f(p.sons_naturais, 'Sons naturais')}
        <button class="btn bgreen" data-assinar="${esc(p.id)}">Assinar no app →</button>
      </div></div>`).join('');
    // Checkout é o MESMO do app (Simplify): abre /planos já logado, com o plano escolhido.
    el('ia-planos').querySelectorAll('[data-assinar]').forEach((b) => b.onclick = () => P().abrirCheckout(b.dataset.assinar));
  }
  // ---------- ligação ----------
  function init() {
    const b = el('btnIA'); if (b) b.onclick = abrir;
    const f = el('iaFechar'); if (f) f.onclick = fechar;
    document.querySelectorAll('#iaPanel .tab-btn').forEach((btn) => btn.addEventListener('click', () => aba(btn.dataset.iatab)));
    // Exposto pro auth-ui/atalhos abrirem o painel de IA de Vendas quando quiser.
    // (Não auto-abre: a extensão abre na tela principal, com o botão "Ligar a extensão".)
    window.LFPainelIA = { abrir, fechar };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
