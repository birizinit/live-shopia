// Modal de confirmação ao "iniciar a live pela extensão" — hookado no botão
// principal "▶ Iniciar ciclo" (#btnCiclo), ANTES do sidebar.js (ofuscado):
// avisa que aqui só transmite áudios prontos e oferece ir pro app.
// Script LIMPO (padrão guia.js/so-audio.js). Não remove nada — só acrescenta.
(function () {
  'use strict';
  const APP_URL = (window.LFPainel && window.LFPainel.PAINEL_URL) || 'https://livefox.com.br';
  let confirmado = false;      // libera o próximo clique (o "Continuar" re-dispara)
  let jaConfirmadoNaSessao = false;   // depois de confirmar 1x, não enche mais no ciclo

  // Só intercepta quando o botão está no estado de INICIAR (texto contém "iniciar");
  // quando o ciclo está rodando o texto vira "Parar/Encerrar" -> deixa passar.
  function vaiIniciar(btn) { return /iniciar/i.test(btn.textContent || ''); }

  function overlay() {
    let ov = document.getElementById('lfLiveModal');
    if (ov) return ov;
    ov = document.createElement('div');
    ov.id = 'lfLiveModal';
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:none;align-items:center;justify-content:center;background:rgba(6,4,12,.72);backdrop-filter:blur(3px);font-family:Poppins,-apple-system,Segoe UI,sans-serif;';
    ov.innerHTML = `
      <div style="width:min(340px,86vw);background:#160c1f;border:1px solid rgba(254,44,85,.35);border-radius:16px;padding:20px 18px;box-shadow:0 18px 60px rgba(0,0,0,.6);">
        <div style="font-size:15px;font-weight:800;color:#fff;margin-bottom:8px;">Tem certeza que deseja iniciar a live por aqui?</div>
        <div style="font-size:12px;line-height:1.55;color:#c9c4e8;">
          Você pode usar o nosso <b style="color:#25F4EE">app</b> para <b>gerar voz e roteiros</b> e transmitir o áudio por ele.
          Aqui você só consegue <b style="color:#FE2C55">transmitir áudios prontos</b>.
          <br><br>
          Se quiser continuar pelo app, clique no botão abaixo — e <b>não esqueça de ativar o botão “Ler comentários” aqui na extensão</b>.
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:16px;">
          <button id="lfLiveGoApp" style="width:100%;padding:11px;border:none;border-radius:10px;font-weight:800;font-size:13px;cursor:pointer;color:#fff;background:linear-gradient(135deg,#FE2C55,#8b5cf6);">Ir pro app →</button>
          <button id="lfLiveStay" style="width:100%;padding:11px;border:1px solid rgba(255,255,255,.18);border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;color:#c9c4e8;background:transparent;">Continuar pela Extensão</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    return ov;
  }

  function abrir(onContinuar) {
    const ov = overlay();
    ov.style.display = 'flex';
    const fechar = () => { ov.style.display = 'none'; };
    ov.querySelector('#lfLiveGoApp').onclick = () => {
      fechar();
      try { window.open(APP_URL + '/estudio', '_blank', 'noopener'); } catch (e) {}
    };
    ov.querySelector('#lfLiveStay').onclick = () => { fechar(); onContinuar(); };
    ov.onclick = (e) => { if (e.target === ov) fechar(); };   // clicar fora fecha (cancela)
  }

  function ligar() {
    const btn = document.getElementById('btnCiclo');
    if (!btn) return false;
    btn.addEventListener('click', (e) => {
      if (confirmado) { confirmado = false; return; }      // já confirmou: deixa passar
      if (jaConfirmadoNaSessao) return;                    // confirma só 1x por sessão
      if (!vaiIniciar(btn)) return;                        // botão está no estado "Parar": passa direto
      // vai INICIAR o ciclo/live -> confirma antes
      e.preventDefault(); e.stopImmediatePropagation();
      abrir(() => {
        jaConfirmadoNaSessao = true;
        confirmado = true;
        btn.click();                                       // re-dispara -> agora passa pro sidebar.js
      });
    }, true);                                              // CAPTURE: roda antes do handler ofuscado
    return true;
  }

  // O #btnCiclo já existe no DOM; se ainda não, tenta de novo.
  if (!ligar()) {
    let n = 0;
    const t = setInterval(() => { if (ligar() || ++n > 40) clearInterval(t); }, 250);
  }
})();
