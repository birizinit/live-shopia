# Ficha da Chrome Web Store — Live Fox (v4.3)

Tudo pronto pra colar no Developer Dashboard. Bate com o `manifest.json` v4.3.
Onde aparecer 【PREENCHER】 troque pelos seus dados reais antes de enviar.

---

## Aba "Informações da loja" (Store listing)

### Nome
Live Fox — Assistente de Live para TikTok Shop

### Descrição curta / Resumo (máx. 132 caracteres)
Automatize sua live no TikTok Shop: boas-vindas, respostas no chat e voz de IA — direto no LIVE Studio, sem stream key.

### Descrição detalhada
O Live Fox é o copiloto da sua live de vendas no TikTok Shop. Ele lê o chat da
live em tempo real, dá boas-vindas a quem entra, responde às dúvidas mais comuns
(preço, frete, tamanho, estoque) e narra seu roteiro de vendas com voz de IA.

O áudio da IA é entregue no TikTok LIVE Studio através de um cabo de áudio
virtual (VB-Cable no Windows ou BlackHole no Mac) — você NÃO precisa de chave de
transmissão (stream key). O Live Fox só coloca a voz; quem transmite o vídeo é o
próprio LIVE Studio.

Como funciona:
1. Você faz login na extensão e configura voz, roteiro e respostas no nosso painel.
2. Instala o cabo de áudio virtual e seleciona ele como microfone no LIVE Studio.
3. Abre sua live: a IA dá boas-vindas, responde o chat e narra suas ofertas.

Recursos:
• Boas-vindas e respostas automáticas no chat da live
• Roteiro de vendas com variação natural (não fica repetitivo)
• Voz de IA realista entregue direto no LIVE Studio
• Alertas de venda no Telegram (opcional, configurado por você)
• Agendamento de início/fim das sessões

Requer uma assinatura ativa (sem plano gratuito) e o cabo de áudio virtual.
Consulte os planos no nosso site.

### Categoria
Produtividade

### Idioma
Português (Brasil)

### Visibilidade
**Não listada** — só quem tem o link (enviado após a compra) instala.

### Gráficos exigidos (você fornece as imagens)
- Ícone da loja: 128×128 PNG (já temos `icon.png`)
- Screenshots: 1280×800 (ou 640×400), pelo menos 1, até 5 — use as de `dist/screenshots`
- (Opcional) Marquee promocional 1400×560

---

## Aba "Práticas de privacidade" (Privacy) — a que mais trava revisão

### Finalidade única (Single purpose)
O Live Fox tem um único propósito: automatizar a interação da sua live de vendas
no TikTok Shop — ler o chat da live para dar boas-vindas, responder perguntas
comuns e narrar seu roteiro de vendas com voz de IA entregue no TikTok LIVE Studio.

### Justificativa de cada permissão

| Permissão | Justificativa (colar) |
|---|---|
| `activeTab` | Interagir com a aba do TikTok que o usuário está usando na live no momento. |
| `scripting` | Injetar, na página da live, a lógica que lê o chat e integra com o painel. |
| `storage` | Guardar localmente as configurações do usuário (voz, roteiro, alertas, token de sessão). |
| `alarms` | Agendar o início e o fim das sessões de live programadas pelo usuário. |
| `sidePanel` | Exibir o painel de controle lateral da extensão (login e controles da live). |
| `tabs` | Identificar e acompanhar a aba correta do TikTok onde a live está acontecendo. |
| Host `*://*.tiktok.com/*` | Ler o chat da live e a página do Shop, onde a extensão opera. |
| Host `https://livefox.com.br/*` | Nosso painel na nuvem: login, verificação de assinatura, geração da voz de IA e autorização de cada sessão. |
| Host `https://api.telegram.org/*` | Enviar alertas de venda ao Telegram — **apenas se o usuário ativar** e informar o próprio bot/chat. |

### Uso de código remoto (Remote code)
**Não.** A extensão não baixa nem executa código remoto. Ela apenas troca DADOS
(JSON e áudio) com o nosso painel via HTTPS; toda a lógica está empacotada no ZIP.

### Coleta de dados do usuário (marcar no dashboard)
Marque estas categorias como coletadas:
- **Informações de identificação pessoal** — e-mail da conta (autenticação).
- **Informações de autenticação** — token/sessão de login.
- **Conteúdo do site** — mensagens do chat da live são lidas e enviadas ao nosso
  servidor para gerar as respostas da IA (não são vendidas nem usadas para outro fim).

NÃO coletamos: saúde, dados financeiros/pagamento (o pagamento é feito no site,
fora da extensão), localização, histórico de navegação, comunicações pessoais.

### As 3 certificações (marque todas — são verdadeiras)
- ☑ Não vendo nem transfiro dados a terceiros fora dos usos aprovados.
- ☑ Não uso os dados para fins não relacionados à finalidade única do item.
- ☑ Não uso os dados para avaliar crédito ou para empréstimos.

### Política de privacidade (URL pública obrigatória)
Hospede o conteúdo de `PRIVACIDADE.md` numa URL pública e cole aqui:
【PREENCHER: https://seusite.com/privacidade】

---

## Aba "Conta" (Account) — foi o que reprovou da última vez ("endereço")
- **E-mail de contato:** verifique/confirme (o Google manda um código).
- **Endereço do desenvolvedor:** preencha um endereço REAL e consistente com o
  que o Google pedir; a reprovação anterior foi por aqui. Contas classificadas
  como "trader" (quem vende) podem exigir endereço público de contato.
- **Taxa única de US$ 5** paga na nova conta.

---

## Checklist final
- [ ] `manifest.json` v4.3 sem `localhost:7892` ✅ já corrigido
- [ ] ZIP `dist/live-fox-4.3.zip` gerado ✅ já gerado
- [ ] Ícone 128×128 e screenshots prontos
- [ ] Política de privacidade hospedada (URL pública)
- [ ] E-mail de contato confirmado
- [ ] Endereço do desenvolvedor preenchido e verificado
- [ ] Visibilidade = Não listada
