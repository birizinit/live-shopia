// Aviso de NOVA VERSÃO da extensão. Compara a versão instalada (manifest) com a
// versão publicada pelo admin (vem em /api/ext/licenca → ext_versao_atual). Se estiver
// desatualizada, mostra um modal com o link do ZIP + instruções de instalar. Script LIMPO.
(function (g) {
  'use strict';
  let dispensada = '';   // versão que o usuário dispensou nesta sessão

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function vcmp(a, b) {
    const pa = String(a || '0').split('.').map((x) => parseInt(x, 10) || 0);
    const pb = String(b || '0').split('.').map((x) => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x > y) return 1; if (x < y) return -1; }
    return 0;
  }
  function minhaVersao() { try { return g.chrome.runtime.getManifest().version; } catch (e) { return '0'; } }

  async function checar() {
    const P = g.LFPainel; if (!P) return;
    try { if (!(await P.estaLogado())) return; } catch (e) { return; }
    let lic; try { lic = await P.licenca(); } catch (e) { return; }
    if (!lic || !lic.ext_versao_atual) return;
    if (vcmp(lic.ext_versao_atual, minhaVersao()) > 0 && dispensada !== lic.ext_versao_atual) {
      mostrar(lic.ext_versao_atual, lic.ext_zip_url, lic.ext_notas);
    }
  }

  function injStyle() {
    if (g.document.getElementById('lfUpdStyle')) return;
    const s = g.document.createElement('style'); s.id = 'lfUpdStyle';
    s.textContent = `
    #lfUpd{position:fixed;inset:0;z-index:100001;display:flex;align-items:center;justify-content:center;padding:18px;font-family:'Space Grotesk',sans-serif;}
    #lfUpd .lfupd-bg{position:absolute;inset:0;background:rgba(4,8,6,.8);backdrop-filter:blur(5px);}
    #lfUpd .lfupd-card{position:relative;width:min(320px,94vw);background:#14121c;border:1px solid rgba(139,92,246,.3);border-radius:16px;padding:20px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.6);color:#eceaff;}
    #lfUpd .lfupd-ic{font-size:34px}
    #lfUpd .lfupd-h{font-size:16px;font-weight:800;margin-top:4px}
    #lfUpd .lfupd-v{font-size:13px;color:#8b5cf6;font-weight:700;margin:2px 0 8px}
    #lfUpd .lfupd-n{font-size:12px;color:#9fb3aa;line-height:1.5;margin-bottom:12px}
    #lfUpd .lfupd-btn{display:block;text-decoration:none;background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;font-weight:800;font-size:13px;padding:12px;border-radius:11px;}
    #lfUpd .lfupd-help{margin-top:10px;text-align:left}
    #lfUpd .lfupd-help summary{font-size:11px;color:#6366f1;cursor:pointer;font-weight:700;text-align:center}
    #lfUpd .lfupd-help ol{margin:8px 0 0;padding-left:18px;font-size:11px;color:#9fb3aa;line-height:1.7}
    #lfUpd .lfupd-help b{color:#eceaff}
    #lfUpd .lfupd-x{margin-top:12px;background:none;border:none;color:#6f857b;font-size:12px;cursor:pointer}`;
    g.document.head.appendChild(s);
  }

  function mostrar(versao, zip, notas) {
    injStyle();
    let ov = g.document.getElementById('lfUpd');
    if (!ov) { ov = g.document.createElement('div'); ov.id = 'lfUpd'; g.document.body.appendChild(ov); }
    ov.innerHTML = `<div class="lfupd-bg"></div><div class="lfupd-card">
      <div class="lfupd-ic">🆕</div>
      <div class="lfupd-h">Nova versão disponível</div>
      <div class="lfupd-v">v${esc(versao)}</div>
      ${notas ? `<div class="lfupd-n">${esc(notas)}</div>` : ''}
      <a class="lfupd-btn" href="${esc(zip)}" target="_blank" rel="noopener" download>⬇️ Baixar a nova versão</a>
      <details class="lfupd-help"><summary>Como instalar</summary>
        <ol>
          <li>Baixe e <b>extraia</b> o ZIP numa pasta fixa (não apague ela depois).</li>
          <li>Abra <b>chrome://extensions</b> e ligue o <b>Modo desenvolvedor</b>.</li>
          <li>Remova a Live Fox antiga (botão Remover).</li>
          <li><b>Carregar sem compactação</b> → escolha a pasta que você extraiu.</li>
        </ol></details>
      <button class="lfupd-x" id="lfUpdX">Agora não</button>
    </div>`;
    const x = g.document.getElementById('lfUpdX');
    if (x) x.onclick = () => { dispensada = versao; ov.remove(); };
  }

  function start() { setTimeout(checar, 3000); setInterval(checar, 300000); }  // 3s após abrir + a cada 5min
  if (g.document.readyState === 'loading') g.document.addEventListener('DOMContentLoaded', start);
  else start();
})(typeof window !== 'undefined' ? window : this);
