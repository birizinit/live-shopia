# Política de Privacidade — Live Fox

_Última atualização: 2026-07-13_

A extensão **Live Fox** ("nós", "a extensão") ajuda vendedores a automatizar
lives no TikTok Shop. Levamos a sério a privacidade dos seus dados. Esta
política explica o que coletamos, por quê e como tratamos.

## O que coletamos

- **Dados de conta:** e-mail e senha (a senha é guardada apenas como hash, nunca
  em texto puro), usados para autenticar você no nosso painel.
- **Identificador de dispositivo:** um `device_id` gerado para vincular a
  assinatura ao seu aparelho (evita compartilhamento indevido de conta).
- **Dados de uso:** tempo de live (em horas) e eventos técnicos da sessão,
  usados para medir consumo do plano e faturar corretamente.
- **Configurações que VOCÊ insere:** por exemplo, seu token de bot do Telegram e
  o Chat ID, quando você opta por receber alertas. Esses valores ficam
  **armazenados localmente no seu navegador** (`chrome.storage.local`) e são
  enviados **apenas** ao serviço que você configurou (a API do Telegram).

## O que NÃO fazemos

- Não coletamos seu histórico de navegação.
- Não vendemos nem alugamos seus dados a terceiros.
- Não injetamos nem executamos código remoto na extensão.
- Não acessamos páginas fora do escopo declarado (TikTok e os serviços que você
  mesmo configura).

## Onde os dados são usados

A extensão se comunica com:

- **Domínios do TikTok** (`*.tiktok.com`) — para ler o chat da live e a página do Shop.
- **Nosso painel de controle** (`livefox.com.br`) — para login, verificação
  de assinatura, geração da voz de IA e autorização de cada sessão. As mensagens
  do chat da live são enviadas a esse serviço apenas para gerar as respostas da IA.
- **API do Telegram** (`api.telegram.org`) — somente se você ativar os alertas de
  venda e informar o seu próprio bot e chat.

O áudio da voz de IA é reproduzido localmente no seu navegador e roteado para o
cabo de áudio virtual (VB-Cable / BlackHole) que você instala — não há nenhum
serviço auxiliar rodando na sua máquina.

## Retenção e exclusão

Mantemos os dados de conta e uso enquanto sua assinatura estiver ativa. Você
pode solicitar a exclusão da sua conta e dos dados associados pelo e-mail de
contato abaixo.

## Segurança

Senhas são protegidas com hash (bcrypt). O acesso às funções pagas é autorizado
pelo servidor a cada sessão, com token de curta duração. A comunicação com o
painel deve ocorrer por HTTPS em produção.

## Contato

Dúvidas sobre esta política: **[SEU-EMAIL-DE-CONTATO]**

> Substitua `[SEU-EMAIL-DE-CONTATO]` pelo e-mail real e hospede esta página numa
> URL pública (ex.: `https://seusite.com/privacidade`). A Chrome Web Store exige
> o link dessa política na aba de listagem.
