// GATE da câmera virtual — roda no mundo ISOLATED (tem chrome.storage/fetch) e avisa
// o mundo MAIN (camera-virtual.js) se a assinatura libera o recurso.
//
// Por que separado: o hook do getUserMedia PRECISA rodar no mundo MAIN e em
// document_start (antes do TikTok pegar navigator.mediaDevices). Lá não existe
// chrome.storage nem chrome.runtime — então quem consulta a licença é este script,
// e a resposta atravessa por window.postMessage.
//
// Diferente do produto de referência (que vinha com o gate desativado, sempre
// "licensed: true"), aqui a câmera virtual É um recurso pago: sem plano ativo, não liga.
(function () {
  'use strict';

  const PAINEL = 'https://livefox.com.br';
  const CANAL_RESPOSTA = 'livefox-camera-gate';
  const CANAL_PEDIDO = 'livefox-camera-gate-pedido';

  const avisar = (dados) => {
    try { window.postMessage({ source: CANAL_RESPOSTA, ...dados }, '*'); } catch (e) {}
  };

  // O contexto da extensão morre quando ela é recarregada; sem isto o console enche de erro.
  const ctxOk = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };

  async function checar() {
    if (!ctxOk()) return;
    try {
      const s = await chrome.storage.local.get(['lf_jwt', 'lf_device_id']);
      if (!s.lf_jwt) return avisar({ liberado: false, motivo: 'login' });
      const url = PAINEL + '/api/ext/licenca?device_id=' + encodeURIComponent(s.lf_device_id || '');
      const r = await fetch(url, { headers: { Authorization: 'Bearer ' + s.lf_jwt } });
      const d = await r.json().catch(() => ({}));
      if (r.status === 401) return avisar({ liberado: false, motivo: 'login' });
      const rec = d.recursos || {};
      avisar({
        // `ativo` = a extensão roda neste plano. `recursos.camera_virtual` = ESTE plano
        // inclui a câmera virtual (o admin liga por plano). Um não implica o outro:
        // o plano Áudio roda a extensão mas pode não ter câmera.
        liberado: !!d.ativo && !!rec.camera_virtual,
        extensaoOk: !!d.ativo,
        recursos: {
          camera_virtual: !!rec.camera_virtual,
          audio_live: !!rec.audio_live,
        },
        motivo: d.motivo || (d.ativo && !rec.camera_virtual ? 'camera_fora_do_plano' : null),
        plano: d.plano_nome || null,
        checkout: d.checkout_url || (PAINEL + '/estudio/planos'),
      });
    } catch (e) {
      // Sem rede: não derruba quem já está transmitindo — o MAIN decide o que fazer.
      avisar({ liberado: false, motivo: 'sem conexão com o servidor', offline: true });
    }
  }

  checar();
  // O plano pode cair no meio da live (limite de horas, assinatura vencida).
  setInterval(checar, 5 * 60 * 1000);
  // O MAIN pede recheck quando o usuário acabou de logar pelo side panel.
  window.addEventListener('message', (e) => {
    if (e.source === window && e.data && e.data.source === CANAL_PEDIDO) checar();
  });
})();
