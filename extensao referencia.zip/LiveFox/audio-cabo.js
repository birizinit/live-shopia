// Áudio direto no CABO VIRTUAL pela extensão — mata o helper Python.
// - Voz premium (ElevenLabs, base64 do painel) -> Audio + setSinkId(cabo).
// - Voz local (grátis) -> speechSynthesis do navegador.
// O cabo (BlackHole/VB-Cable/Voicemeeter) é o ÚNICO nativo que resta.
(function (g) {
  'use strict';
  const NOMES_CABO = ['cable', 'vb-audio', 'blackhole', 'voicemeeter', 'cabo'];
  let sinkId = null, sinkLabel = null;

  // Precisa de permissão de microfone 1x pra o navegador revelar os LABELS das saídas.
  async function permitir() {
    try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach((t) => t.stop()); return true; }
    catch { return false; }
  }

  async function acharCabo() {
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      const cabo = devs.filter((d) => d.kind === 'audiooutput')
        .find((d) => NOMES_CABO.some((n) => (d.label || '').toLowerCase().includes(n)));
      sinkId = cabo ? cabo.deviceId : null;
      sinkLabel = cabo ? cabo.label : null;
      return sinkLabel;
    } catch { return null; }
  }

  function b64ToBlob(b64, mime) {
    const bin = atob(b64); const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }

  // Toca um áudio (base64) NO CABO e resolve quando termina (pra fila cadenciar de verdade).
  async function tocarBase64(b64, { mime = 'audio/mpeg', volume = 1 } = {}) {
    const url = URL.createObjectURL(b64ToBlob(b64, mime));
    const a = new Audio(url);
    a.volume = volume;
    if (sinkId && a.setSinkId) { try { await a.setSinkId(sinkId); } catch { /* sem permissão de sink */ } }
    try { await a.play(); } catch { URL.revokeObjectURL(url); return 0; }
    return new Promise((res) => { a.onended = a.onerror = () => { URL.revokeObjectURL(url); res(a.duration || 0); }; });
  }

  // Voz local grátis (Web Speech). Toca na saída PADRÃO do sistema — por isso o
  // usuário do plano grátis deve deixar o cabo como saída padrão (mesma config de sempre).
  function falarLocal(texto, { idioma = 'pt-BR', volume = 1 } = {}) {
    return new Promise((res) => {
      if (!g.speechSynthesis) return res(0);
      const u = new SpeechSynthesisUtterance(texto);
      u.lang = idioma; u.volume = volume;
      u.onend = u.onerror = () => res(0);
      g.speechSynthesis.speak(u);
    });
  }

  g.LFAudio = {
    permitir, acharCabo, tocarBase64, falarLocal,
    get sinkId() { return sinkId; }, get cabo() { return sinkLabel; },
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
