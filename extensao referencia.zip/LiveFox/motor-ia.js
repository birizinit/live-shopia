// MOTOR DE IA no navegador — substitui o cérebro (Node) e o helper (Python).
// Lê o chat da TikTok (DOM), gera boas-vindas/respostas por tema, narra o roteiro,
// e toca a voz no cabo (premium via painel+setSinkId; local via speechSynthesis).
// Usa o SDK LFPainel (gate/heartbeat/config/voz) e LFAudio (cabo). 1 live por conta.
(function (g) {
  'use strict';

  // ───────── Texto (portado do roteiro.js, sem dependência) ─────────
  function spin(texto, vars = {}) {
    let t = texto;
    for (const [k, v] of Object.entries(vars)) t = t.split(`[${k}]`).join(v ?? '');
    const re = /\{([^{}]*)\}/; let m, guard = 0;
    while ((m = re.exec(t)) && guard++ < 200) {
      const op = m[1].split('|'); const esc = op[Math.floor(Math.random() * op.length)];
      t = t.slice(0, m.index) + esc + t.slice(m.index + m[0].length);
    }
    return t.replace(/\s+/g, ' ').trim();
  }
  const normalizar = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  function casarTema(coment, temas) {
    const c = normalizar(coment); if (!c) return null;
    for (const t of (temas || [])) {
      const gats = (t.gatilhos || []).map(normalizar).filter(Boolean);
      if (gats.some((gt) => c.includes(gt))) return t;
    }
    return null;
  }
  function responderTema(tema, vars = {}) {
    const op = (tema?.respostas || []).filter(Boolean);
    return op.length ? spin(op[Math.floor(Math.random() * op.length)], { nome: 'amor', ...vars }) : null;
  }
  const TEMAS_PADRAO = [
    { nome: 'preço', gatilhos: ['preço', 'preco', 'quanto', 'valor', 'custa'], respostas: ['{Oi|Olá} [nome], sai por R$ [preco]! {Aproveita|Corre garantir}.'] },
    { nome: 'frete', gatilhos: ['frete', 'entrega', 'envio', 'chega'], respostas: ['[nome], {enviamos|entregamos} pro Brasil todo! Frete no carrinho.'] },
    { nome: 'como comprar', gatilhos: ['como compra', 'link', 'carrinho', 'sacolinha', 'comprar'], respostas: ['[nome], é só {tocar na sacolinha|clicar no carrinho} aqui embaixo!'] },
  ];
  const gerarBoasVindas = (nome, tpl) => spin(tpl || '{Seja bem-vinda|Bem-vindo|Que bom te ver}, [nome]! {Cola aqui|Fica à vontade} na live.', { nome: nome || 'amor' });

  // ───────── Estado (uma sessão — 1 live por conta) ─────────
  const CFG = {
    boas_vindas: true, resposta: true, modo: 'on', idioma_saida: 'pt-BR', volume: 1.0, fonte: 'local',
    texto_boas_vindas: null, roteiro: null, roteiro_ativo: true, roteiro_gap_ms: 7000, cadencia_ms: 400,
    max_fila: 5, resp_por_min: 25, temas: null, vars: { produto: '', preco: '' }, tema_cooldown_ms: 25000,
    duracao_min: 0,   // 0 = sem limite; >0 = encerra sozinho após esse tempo (o bloco repete até lá)
    resposta_ia: true,        // híbrido: comentário sem tema vai pra IA (Claude) gerar resposta
    ia_cooldown_ms: 12000,    // no mín. este intervalo entre respostas por IA (segura custo)
    welcome_cooldown_ms: 120000, // saúda quem entra no máx. 1x a cada 2min (senão trava o roteiro)
  };
  const S = { ativo: false, config: { ...CFG }, fila: [], falando: false, roteiroIdx: 0, ultimaFala: 0,
    temaUltimo: {}, respTs: [], ouvintes: new Set(), recursos: null, paradaTimer: null, iniciadaEm: 0,
    iaUltima: 0,   // timestamp da última resposta gerada por IA (cooldown do híbrido)
    // Pré-geração: cache de áudio do roteiro (texto -> {audio_b64,mime,chars}) + requisições em voo.
    audioCache: new Map(), emVoo: new Map(), pregerando: false };

  const emitir = (ev) => { for (const fn of S.ouvintes) { try { fn(ev); } catch {} } return ev; };
  const assinar = (fn) => { S.ouvintes.add(fn); return () => S.ouvintes.delete(fn); };
  const configurar = (patch) => { Object.assign(S.config, patch); return S.config; };
  function definirRoteiro(entrada) {
    let seg = Array.isArray(entrada) ? entrada : (typeof entrada === 'string' ? entrada.split(/(?<=[.!?])\s+|\n+/) : []);
    S.config.roteiro = seg.map((x) => x.trim()).filter(Boolean); S.roteiroIdx = 0; return S.config.roteiro;
  }

  // Sintetiza a voz (nuvem) de UM texto, com cache local + dedupe de requisições
  // em voo (se o mesmo texto já está sendo gerado, compartilha a mesma promise —
  // evita chamada dupla quando a pré-geração e a fala pedem o mesmo trecho).
  async function sintetizar(texto) {
    if (S.audioCache.has(texto)) return S.audioCache.get(texto);
    if (S.emVoo.has(texto)) return S.emVoo.get(texto);
    const p = (async () => {
      try {
        const r = await g.LFPainel.voz(texto, { idioma: S.config.idioma_saida });
        if (r && r.ok && r.audio_b64) { const a = { audio_b64: r.audio_b64, mime: r.mime, chars: r.chars }; S.audioCache.set(texto, a); return a; }
      } catch { /* rede/limite: cai no local no falar() */ }
      return null;
    })();
    S.emVoo.set(texto, p);
    const a = await p; S.emVoo.delete(texto); return a;
  }

  // Pré-gera o áudio de TODO o roteiro em segundo plano ANTES/enquanto a live roda.
  // Assim, na hora de falar, é só tocar o áudio pronto (instantâneo, sem depender
  // da rede no meio da live). Roda com concorrência limitada pra não sobrecarregar.
  async function pregerarRoteiro() {
    const c = S.config;
    if (c.fonte !== 'nuvem' || !g.LFPainel || !c.roteiro?.length) return;
    S.pregerando = true;
    const fila = c.roteiro.filter((t) => !S.audioCache.has(t));
    const total = fila.length; let feito = 0;
    emitir({ tipo: 'pregerando', feito: 0, total, texto: total ? `Preparando a voz do roteiro (0/${total})…` : 'Voz do roteiro já pronta.' });
    const CONC = 3; let i = 0;
    async function worker() {
      while (S.ativo && i < fila.length) {
        const idx = i++;
        await sintetizar(fila[idx]);
        feito++;
        if (feito % 3 === 0 || feito === total) emitir({ tipo: 'pregerando', feito, total, texto: `Preparando a voz do roteiro (${feito}/${total})…` });
      }
    }
    await Promise.all(Array.from({ length: Math.min(CONC, total) }, worker));
    S.pregerando = false;
    if (S.ativo) emitir({ tipo: 'sistema', texto: `✅ Voz do roteiro pronta (${feito}/${total}) — tocando sem atraso.` });
  }

  // toca a fala e RESOLVE quando o áudio termina (cadência exata, sem sobrepor)
  async function falar(texto) {
    const c = S.config;
    if (c.fonte === 'nuvem' && g.LFPainel && g.LFAudio) {
      const cacheado = S.audioCache.has(texto);
      const a = await sintetizar(texto);   // cache-first: pré-gerado toca na hora
      if (a) { await g.LFAudio.tocarBase64(a.audio_b64, { mime: a.mime, volume: c.volume }); return { falado: true, fonte: cacheado ? 'pre' : 'nuvem', chars: a.chars }; }
      emitir({ tipo: 'aviso', texto: 'voz premium indisponível; usando local' });
    }
    if (g.LFAudio) await g.LFAudio.falarLocal(texto, { idioma: c.idioma_saida, volume: c.volume });
    return { falado: true, fonte: 'local' };
  }

  function enfileirar(item) { if (S.fila.length >= S.config.max_fila) { S.fila.shift(); } S.fila.push(item); }
  function podeResponder() {
    const agora = Date.now(); S.respTs = S.respTs.filter((t) => agora - t < 60000);
    if (S.respTs.length >= S.config.resp_por_min) return false; S.respTs.push(agora); return true;
  }

  async function bombear() {
    if (S.falando) return; S.falando = true;
    const pausa = (ms) => new Promise((r) => setTimeout(r, ms));
    while (S.ativo) {
      const c = S.config; let item = S.fila.shift();
      if (!item && c.roteiro_ativo && c.roteiro?.length && (Date.now() - S.ultimaFala) >= c.roteiro_gap_ms) {
        item = { texto: c.roteiro[S.roteiroIdx % c.roteiro.length], tipo: 'roteiro' }; S.roteiroIdx++;
      }
      if (!item) { await pausa(200); continue; }
      const r = await falar(item.texto); S.ultimaFala = Date.now();
      emitir({ tipo: item.tipo, resposta: item.texto, ...(item.extra || {}), ...r });
      await pausa(c.cadencia_ms || 300);
    }
    S.falando = false;
  }

  function aoEntrar(nome) {
    const c = S.config; emitir({ tipo: 'entrada', nome });
    if (!c.boas_vindas || c.modo === 'off') return;
    // Anti-flood: em live cheia entra gente toda hora. Saúda no máx. 1 por cooldown,
    // senão a IA só dá boas-vindas e o roteiro nunca sai.
    const agora = Date.now();
    if (agora - (S.ultimoWelcome || 0) < (c.welcome_cooldown_ms || 120000)) return emitir({ tipo: 'entrada', nome, saudado: false, motivo: 'welcome_cooldown' });
    S.ultimoWelcome = agora;
    enfileirar({ texto: gerarBoasVindas(nome, c.texto_boas_vindas), tipo: 'boas_vindas', extra: { nome } });
  }
  // Híbrido: 1) tenta casar um TEMA cadastrado (resposta instantânea, sem custo de IA);
  // 2) se não casar e `resposta_ia` estiver ligado, pede uma resposta à IA (Claude) no
  // painel e fala. A IA tem cooldown próprio (ia_cooldown_ms) pra não estourar custo.
  async function aoComentar(nome, texto) {
    const c = S.config;
    if (!c.resposta || c.modo === 'off') return emitir({ tipo: 'comentario', nome, texto, respondido: false });
    const agora = Date.now();
    const tema = casarTema(texto, c.temas || TEMAS_PADRAO);
    if (tema) {
      if (agora - (S.temaUltimo[tema.nome] || 0) < c.tema_cooldown_ms) return emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'cooldown' });
      if (!podeResponder()) return emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'limite/min' });
      S.temaUltimo[tema.nome] = agora;
      const resp = responderTema(tema, { nome: nome || 'amor', produto: c.vars?.produto || '', preco: c.vars?.preco || '' });
      if (!resp) return emitir({ tipo: 'comentario', nome, texto, respondido: false });
      emitir({ tipo: 'comentario', nome, texto, respondido: true, tema: tema.nome, fonte_resp: 'tema' });
      enfileirar({ texto: resp, tipo: 'resposta', extra: { nome, texto, tema: tema.nome } });
      return;
    }
    // ---- sem tema: fallback pra IA (híbrido) ----
    if (!c.resposta_ia || !g.LFPainel || !g.LFPainel.responder) return emitir({ tipo: 'comentario', nome, texto, respondido: false });
    if (S.recursos && S.recursos.respostas_chat === false) return emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'sem respostas_chat' });
    if (agora - S.iaUltima < (c.ia_cooldown_ms || 12000)) return emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'ia_cooldown' });
    if (!podeResponder()) return emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'limite/min' });
    S.iaUltima = agora;
    emitir({ tipo: 'comentario', nome, texto, respondido: false, pendente_ia: true });
    try {
      const r = await g.LFPainel.responder(texto, { nome, produto: c.vars?.produto || '', preco: c.vars?.preco || '' });
      if (!S.ativo) return;   // live pode ter encerrado durante a chamada
      if (r && r.ok && r.resposta) {
        emitir({ tipo: 'comentario', nome, texto, respondido: true, fonte_resp: 'ia' });
        enfileirar({ texto: r.resposta, tipo: 'resposta', extra: { nome, texto, fonte_resp: 'ia' } });
      } else {
        emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: (r && r.erro) || 'ia_sem_resposta' });
      }
    } catch (e) {
      emitir({ tipo: 'comentario', nome, texto, respondido: false, motivo: 'ia_erro' });
    }
  }

  async function iniciar(tiktokUser) {
    const p = await g.LFPainel.autorizarLive(tiktokUser);       // gate paid-only + limite de contas + heartbeat (o SDK cuida)
    if (!p.ok) { emitir({ tipo: 'bloqueado', texto: 'Live bloqueada: ' + p.erro }); return { ativo: false, motivo: p.erro }; }
    S.recursos = p.recursos || null;
    try { const d = await g.LFPainel.getConfig(); if (d.config) { const { roteiro, ...resto } = d.config; Object.assign(S.config, resto); if (roteiro) definirRoteiro(roteiro); } if (d.recursos) S.recursos = d.recursos; } catch {}
    if (S.recursos) { if (S.recursos.respostas_chat === false) S.config.resposta = false; if (S.recursos.voz_premium === false && S.config.fonte === 'nuvem') S.config.fonte = 'local'; }
    S.ativo = true; S.fila = []; S.roteiroIdx = 0; S.ultimaFala = 0; S.temaUltimo = {}; S.respTs = []; S.iaUltima = 0; S.ultimoWelcome = 0;
    S.iniciadaEm = Date.now();
    S.audioCache = new Map(); S.emVoo = new Map();   // cache novo por live (roteiro/voz podem ter mudado)
    if (g.LFPainel.onParar) g.LFPainel.onParar((motivo) => { emitir({ tipo: 'bloqueado', texto: 'Live encerrada: ' + motivo }); parar(); });
    // Auto-stop por duração: o bloco repete até bater o tempo escolhido, aí encerra sozinho.
    if (S.paradaTimer) { clearTimeout(S.paradaTimer); S.paradaTimer = null; }
    const durMin = Number(S.config.duracao_min) || 0;
    if (durMin > 0) S.paradaTimer = setTimeout(() => { emitir({ tipo: 'sistema', texto: `Duração de ${durMin}min atingida — encerrando a live.` }); parar(); }, durMin * 60000);
    bombear();
    pregerarRoteiro();   // pré-gera o áudio do roteiro em segundo plano (a live não espera)
    emitir({ tipo: 'sistema', texto: `IA iniciada — plano ${p.plano}, ${p.restante_horas?.toFixed?.(1) ?? '?'}h${durMin ? `, duração ${durMin}min` : ''}` });
    return { ativo: true, restante_horas: p.restante_horas, duracao_min: durMin };
  }
  function parar() { S.ativo = false; S.fila = []; if (S.paradaTimer) { clearTimeout(S.paradaTimer); S.paradaTimer = null; } if (g.LFPainel && g.LFPainel.encerrarLive) g.LFPainel.encerrarLive(); return { ativo: false }; }
  const estado = () => ({ ativo: S.ativo, fila: S.fila.length, recursos: S.recursos });

  // Lê o chat da TikTok pelo DOM (substitui o tiktok-live-connector do Node).
  // ⚠️ Seletores mudam quando o TikTok altera o layout — ajustar contra a live real.
  function observarChat() {
    const alvo = document.querySelector('[class*="ChatMessage" i], [class*="chatroom" i], [data-e2e*="live" i]') || document.body;
    const visto = new WeakSet();
    const obs = new MutationObserver((muts) => {
      for (const m of muts) for (const node of m.addedNodes) {
        if (node.nodeType !== 1 || visto.has(node)) continue; visto.add(node);
        const txt = (node.innerText || node.textContent || '').trim(); if (!txt) continue;
        const mEntrou = txt.match(/^(.+?)\s+(entrou|joined|acabou de entrar)/i);
        if (mEntrou) { aoEntrar(mEntrou[1].trim()); continue; }
        const mComent = txt.match(/^(.+?)[:：]\s*(.+)$/);
        if (mComent) aoComentar(mComent[1].trim(), mComent[2].trim());
      }
    });
    obs.observe(alvo, { childList: true, subtree: true });
    return () => obs.disconnect();
  }

  const API = { iniciar, parar, estado, assinar, configurar, definirRoteiro, aoEntrar, aoComentar, observarChat,
    // puros (reuso/teste):
    spin, casarTema, responderTema, TEMAS_PADRAO, gerarBoasVindas, _S: S };
  g.LFMotor = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
