// LIVE FOX - Background v5

let timerInterval = null;
let tikTokTabId = null; // ID da aba do TikTok registrada
let timerPausado  = false;
let scanInterval  = null;
let liveCheckInterval = null;
let inicioSessao  = null;

// Cloud config
let cloudCfg = { url: '', canal: '', ntfy: '', ativo: false };

// Licenca → Acesso por e-mail + token
let acessoInterval = null;

let estado = {
  ciclando:     false,
  timerSecs:    0,
  scanN:        0,
  alertas:      0,
  agendado:     false,
  horaAgendada: '',
  liveAtiva:    false,
  abaConectada: false,
  ultimosViewers: '—',
  ultimasVendas:  '—',
  cfg: { threshold: 50, intervalo: 3, duracaoHoras: 4 }
};

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'iniciarCiclo') {
    iniciarCiclo(msg.data);
    sendResponse({ ok: true });
  }
  if (msg.action === 'pararCiclo') {
    pararCiclo();
    sendResponse({ ok: true });
  }
  if (msg.action === 'setModoCupom') {
    enviarContent('setModoCupom', { ativo: msg.ativo });
    sendResponse({ ok: true });
  }

  if (msg.action === 'registrarAba') {
    if (sender && sender.tab) {
      tikTokTabId = sender.tab.id;
      log('Aba TikTok registrada: ' + tikTokTabId);
    }
    sendResponse({ ok: true });
  }

  if (msg.action === 'startBlock') {
    const words = msg.words;
    function enviarStartBlock(tabId) {
      chrome.tabs.sendMessage(tabId, { action: 'startBlock', words: words }, () => {
        if (chrome.runtime.lastError) {}
      });
    }
    if (tikTokTabId) {
      enviarStartBlock(tikTokTabId);
    } else {
      chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        if (!tabs || !tabs.length) return;
        const tab = tabs.find(t => t.url.includes('streamer') || t.url.includes('live')) || tabs[0];
        enviarStartBlock(tab.id);
      });
    }
    sendResponse({ ok: true });
  }
  if (msg.action === 'stopBlock') {
    function enviarStopBlock(tabId) {
      chrome.tabs.sendMessage(tabId, { action: 'stopBlock' }, () => {
        if (chrome.runtime.lastError) {}
      });
    }
    if (tikTokTabId) {
      enviarStopBlock(tikTokTabId);
    } else {
      chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        if (!tabs || !tabs.length) return;
        const tab = tabs.find(t => t.url.includes('streamer') || t.url.includes('live')) || tabs[0];
        enviarStopBlock(tab.id);
      });
    }
    sendResponse({ ok: true });
  }

  if (msg.action === 'fixarAgora') {
    enviarContent('fixarProduto', {});
    sendResponse({ ok: true });
  }
  if (msg.action === 'encerrarLive') {
    pararCiclo();
    enviarContent('encerrarLive', {});
    sendResponse({ ok: true });
  }
  if (msg.action === 'agendarCiclo') {
    agendarCiclo(msg.horaAgendada, msg.cfg);
    sendResponse({ ok: true });
  }
  if (msg.action === 'cancelarAgendamento') {
    estado.agendado = false;
    estado.horaAgendada = '';
    chrome.alarms.clear('agendamento');
    salvarEstado();
    enviarSidebar('estadoUpdate', estado);
    sendResponse({ ok: true });
  }
  if (msg.action === 'pausarTimer') {
    timerPausado = true;
    salvarEstado();
    enviarSidebar('timerPausou', { secs: estado.timerSecs, str: secsStr(estado.timerSecs) });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.action === 'despausarTimer') {
    timerPausado = false;
    salvarEstado();
    enviarSidebar('timerDespausou', { secs: estado.timerSecs, str: secsStr(estado.timerSecs) });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.action === 'getEstado') {
    sendResponse(estado);
  }
  if (msg.action === 'setModoViolacao') {
    estado.cfg = estado.cfg || {};
    estado.cfg.modoViolacao    = msg.modo;
    estado.cfg.minutosViolacao = msg.minutos;
    salvarEstado();
    sendResponse({ ok: true });
  }



  if (msg.action === 'liveStatusUpdate') {
    // Content script reporta status da live
    const antes = estado.liveAtiva;
    estado.liveAtiva    = msg.liveAtiva;
    estado.abaConectada = msg.abaConectada;
    salvarEstado();
    enviarSidebar('liveStatusUpdate', {
      liveAtiva:    estado.liveAtiva,
      abaConectada: estado.abaConectada
    });
    // Se live acabou de ficar ativa e ciclo tá rodando → mostra popup
    if (!antes && estado.liveAtiva && estado.ciclando) {
      enviarContent('mostrarPopupLiveAtiva', {});
    }
  }
  if (msg.action === 'blockLogUpdate') {
    enviarSidebar('blockLogUpdate', msg.data);
    return true;
  }

  if (msg.action === 'bloqueioRegistrado') {
    enviarSidebar('bloqueioRegistrado', msg.data);
    return true;
  }

  if (msg.action === 'statusUpdate') {
    enviarSidebar('statusFromContent', msg.data);
    // Guarda últimas métricas para o relatório
    if (msg.data?.viewers && msg.data.viewers !== '—') estado.ultimosViewers = msg.data.viewers;
    if (msg.data?.gmv && msg.data.gmv !== '—') estado.ultimoGMV = msg.data.gmv;
    if (msg.data?.ultimaVendaValor && msg.data.ultimaVendaValor !== '—') estado.ultimaVendaValor = msg.data.ultimaVendaValor;
    // Notificação por Atividade (quando contador ainda está em 0)
    if (msg.data?.novaVendaAtividade) {
      notificarVenda(
        msg.data.viewers || '—',
        msg.data.vendas || '—',
        msg.data.ultimaVendaValor || '—',
        msg.data.gmv || '—'
      );
    }
    if (msg.data?.vendas  && msg.data.vendas  !== '—') {
      const vendaNova = parseInt(msg.data.vendas) || 0;
      const vendaAnt  = parseInt(estado.ultimasVendas) || 0;
      // Notifica desde a primeira venda (removido vendaAnt > 0)
      if (vendaNova > vendaAnt) {
        notificarVenda(estado.ultimosViewers, msg.data.vendas, estado.ultimaVendaValor || '—', estado.ultimoGMV || '—');
      }
      estado.ultimasVendas = msg.data.vendas;
    }
    if (msg.data?.alerta) {
      estado.alertas++;
      tratarViolacao();
    }
  }
  return true;
});

// ── VIOLAÇÃO ──
function tratarViolacao() {
  if (estado._violacaoAtiva) return;
  estado._violacaoAtiva = true;

  const cfg = estado.cfg || {};
  const modoViolacao = cfg.modoViolacao || 'encerrar';
  const minutosExtra = parseInt(cfg.minutosViolacao) || 0;

  enviarSidebar('violacaoUpdate', { modo: modoViolacao, minutos: minutosExtra });
  notificarViolacao(); // Telegram

  if (modoViolacao === 'encerrar' || minutosExtra <= 0) {
    // Encerra imediatamente
    log('Violação → encerrando agora');
    estado._violacaoAtiva = false;
    enviarSidebar('violacaoDetectada', { pixels: 999, encerrando: true });
    enviarContent('violacaoDetectada', { pixels: 999, encerrando: true });
    pararCiclo();
    enviarContent('encerrarLive', {});
  } else {
    // Modo continuar — ciclo e timer seguem normalmente, só agenda o encerramento da live
    log(`Violação → ciclo continua, live encerra em ${minutosExtra} min`);
    enviarSidebar('violacaoDetectada', { pixels: 999, encerrando: false, minutosExtra });
    enviarContent('violacaoDetectada', { pixels: 999, encerrando: false, minutosExtra });

    if (estado._violacaoInterval) {
      clearInterval(estado._violacaoInterval);
      estado._violacaoInterval = null;
    }

    let secsRestantes = minutosExtra * 60;
    const countdownInterval = setInterval(() => {
      secsRestantes--;
      enviarSidebar('violacaoCountdown', { secs: secsRestantes, str: secsStr(secsRestantes) });
      if (secsRestantes <= 0) {
        clearInterval(countdownInterval);
        estado._violacaoInterval = null;
        estado._violacaoAtiva    = false;
        pararCiclo();
        enviarContent('encerrarLive', {});
        enviarSidebar('violacaoEncerrou', {});
      }
    }, 1000);
    estado._violacaoInterval = countdownInterval;
  }
}

// ── CICLO ──
function iniciarCiclo(cfg) {
  if (estado.ciclando) pararCiclo();
  estado.ciclando   = true;
  estado.cfg        = cfg;
  // Garante duração mínima de 6 minutos (evita bug do teste 0.003h)
  // Aceita duracaoMinutos ou duracaoHoras
  const minutos = cfg.duracaoMinutos || (cfg.duracaoHoras * 60) || 60;
  const minutosSeguro = Math.max(minutos, 1); // mínimo 1 minuto
  estado.timerSecs = Math.round(minutosSeguro * 60);
  estado.scanN         = 0;
  estado.alertas       = 0;
  estado._violacaoAtiva = false;
  inicioSessao         = Date.now();
  salvarEstado();
  iniciarTimerBG();
  iniciarScanBG();
  iniciarLiveCheckBG();
  enviarContent('iniciarCiclo', cfg);
  enviarSidebar('estadoUpdate', estado);
  notificarInicio();
  iniciarVerificacaoAcesso();
}

function pararCiclo() {
  if (estado.ciclando && inicioSessao) gerarRelatorio();
  timerPausado = false;
  estado.ciclando = false;
  if (estado._violacaoInterval) {
    clearInterval(estado._violacaoInterval);
    estado._violacaoInterval = null;
  }
  estado._violacaoAtiva = false;
  salvarEstado();
  pararTimerBG();
  pararScanBG();
  pararLiveCheckBG();
  enviarContent('pararCiclo', {});
  enviarSidebar('estadoUpdate', estado);
  notificarEncerramento();
  pararVerificacaoAcesso();
}

// ── AGENDAMENTO ──
function agendarCiclo(hora, cfg) {
  estado.agendado     = true;
  estado.horaAgendada = hora;
  estado.cfg          = cfg;
  salvarEstado();
  const [h, m] = hora.split(':').map(Number);
  const agora = new Date();
  const alvo  = new Date();
  alvo.setHours(h, m, 0, 0);
  if (alvo <= agora) alvo.setDate(alvo.getDate() + 1);
  chrome.alarms.create('agendamento', { delayInMinutes: (alvo - agora) / 60000 });
  enviarSidebar('estadoUpdate', estado);
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'agendamento' && estado.agendado) {
    estado.agendado = false;
    salvarEstado();
    enviarSidebar('agendamentoDisparou', {});
    log('Agendamento disparou! Iniciando live...');

    // Chama Python pra iniciar live no Live Studio
    // Ativa o ciclo diretamente — sem servidor Python
    iniciarCiclo(estado.cfg);
  }
});

function log(msg) {
  console.log(`[LIVE FOX BG] ${msg}`);
}

// ── TIMER BG ──
function iniciarTimerBG() {
  pararTimerBG();
  timerInterval = setInterval(() => {
    if (!estado.ciclando) { pararTimerBG(); return; }
    if (timerPausado) return; // pausado — não decrementa
    estado.timerSecs--;
    if (estado.timerSecs <= 0) {
      gerarRelatorio();
      pararTimerBG();
      pararScanBG();
      pararLiveCheckBG();
      estado.ciclando = false;
      salvarEstado();
      enviarContent('encerrarLive', {});
      enviarContent('timerZerou',   {});
      enviarSidebar('timerZerou',   {});
      enviarSidebar('estadoUpdate', estado);
      return;
    }
    const str = secsStr(estado.timerSecs);
    enviarSidebar('timerTick', { str, secs: estado.timerSecs });
    enviarContent('timerTick',  { str });
    // Envia ao cloud a cada 5s
  }, 1000);
}
function pararTimerBG() { clearInterval(timerInterval); timerInterval = null; }

// ── SCAN BG ──
function iniciarScanBG() {
  pararScanBG();
  // Piso de 8s entre varreduras: as leituras de tela percorrem o DOM da live (grande e
  // crescente). Rodar isso a cada 3s travava o navegador de quem está ao vivo.
  const intervalo = Math.max(Number(estado.cfg?.intervalo) || 8, 8) * 1000;
  scanInterval = setInterval(() => {
    if (!estado.ciclando) { pararScanBG(); return; }
    estado.scanN++;
    salvarEstado();
    enviarSidebar('scanTick', { n: estado.scanN });
    chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
      if (!tabs || !tabs.length) return;
      const tabScan = tabs.find(t => t.url.includes('streamer') || t.url.includes('console') || t.url.includes('live')) || tabs[0];
      chrome.tabs.sendMessage(tabScan.id, { action: 'calibrar' }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        enviarSidebar('meterUpdate', { pixels: res.pixels, threshold: estado.cfg.threshold });
        if (res.pixels >= estado.cfg.threshold) {
          if (estado._violacaoAtiva) return;
          estado.alertas++;
          tratarViolacao();
        }
      });
    });
  }, intervalo);
}
function pararScanBG() { clearInterval(scanInterval); scanInterval = null; }

// ── LIVE CHECK BG — verifica se live está ativa ──
function iniciarLiveCheckBG() {
  pararLiveCheckBG();
  liveCheckInterval = setInterval(() => {
    chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
      if (!tabs || !tabs.length) return;
      const tabLive = tabs.find(t => t.url.includes('streamer') || t.url.includes('console') || t.url.includes('live')) || tabs[0];
      chrome.tabs.sendMessage(tabLive.id, { action: 'checkLive' }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        chrome.runtime.sendMessage({
          action:       'liveStatusUpdate',
          liveAtiva:    res.liveAtiva,
          abaConectada: res.abaConectada
        }, () => { if (chrome.runtime.lastError) {} });
        // Atualiza estado
        estado.liveAtiva    = res.liveAtiva;
        estado.abaConectada = res.abaConectada;
        enviarSidebar('liveStatusUpdate', {
          liveAtiva:    res.liveAtiva,
          abaConectada: res.abaConectada
        });
      });
    });
  }, 10000);
}
function pararLiveCheckBG() { clearInterval(liveCheckInterval); liveCheckInterval = null; }

// ── RELATÓRIO ──
function gerarRelatorio() {
  if (!inicioSessao) return;
  const dur = Date.now() - inicioSessao;
  const rel = {
    horas:   (dur / 3600000).toFixed(1),
    minutos: Math.round(dur / 60000),
    scans:   estado.scanN,
    alertas: estado.alertas,
    inicio:  new Date(inicioSessao).toLocaleTimeString('pt-BR'),
    fim:     new Date().toLocaleTimeString('pt-BR'),
    data:    new Date().toLocaleDateString('pt-BR'),
    viewers: estado.ultimosViewers || '—',
    vendas:  estado.ultimasVendas  || '—',
  };
  enviarSidebar('relatorio', rel);
  enviarContent('relatorioSessao', rel);
  chrome.storage.local.set({ infinityUltimoRelatorio: rel });
  chrome.storage.local.get('infinityHistorico', (d) => {
    const hist = d.infinityHistorico || [];
    hist.unshift(rel);
    if (hist.length > 30) hist.pop();
    chrome.storage.local.set({ infinityHistorico: hist });
  });
  inicioSessao = null;
}

// ── HELPERS ──
// Notificações agora vão pro APP (PWA) do usuário via PUSH — não mais pro Telegram.
// A extensão avisa o backend (com o JWT do login do painel, salvo em lf_jwt) e o backend
// dispara a notificação pro celular/computador do próprio usuário.
const LF_PAINEL_URL = 'https://livefox.com.br';
function avisarApp(path, corpo) {
  chrome.storage.local.get('lf_jwt', (d) => {
    if (!d.lf_jwt) return; // sem login no painel não há pra quem/como notificar
    fetch(LF_PAINEL_URL + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + d.lf_jwt },
      body: JSON.stringify(corpo || {}),
    }).catch(() => {});
  });
}

function notificarVenda(viewers, vendas, ultimaVendaValor, gmv) {
  avisarApp('/api/push/venda', { valor: ultimaVendaValor, vendas, gmv, viewers });
}

// Início/encerramento/violação: Telegram removido. (Mantidos como no-op pra não quebrar
// os pontos que chamam essas funções; se quiser, dá pra virar push também no futuro.)
function notificarInicio() {}
function notificarEncerramento() {}
function notificarViolacao() {}

function enviarContent(action, data) {
  chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
    if (!tabs || !tabs.length) return;
    const tab = tabs.find(t => t.url.includes('streamer') || t.url.includes('console') || t.url.includes('live')) || tabs[0];
    chrome.tabs.sendMessage(tab.id, { action, data }, () => {
      if (chrome.runtime.lastError) {} // ignora erro silencioso
    });
  });
}
function enviarSidebar(action, data) {
  chrome.runtime.sendMessage({ action, data }, () => {
    if (chrome.runtime.lastError) {}
  });
}
function salvarEstado() {
  chrome.storage.local.set({ infinityEstado: estado });
}
function secsStr(s) {
  return pad(Math.floor(s/3600))+':'+pad(Math.floor((s%3600)/60))+':'+pad(s%60);
}
function pad(n) { return String(n).padStart(2,'0'); }

// ── VERIFICACAO DE ACESSO (e-mail + token) ──
function iniciarVerificacaoAcesso() {
  pararVerificacaoAcesso();
  verificarAcesso();
  acessoInterval = setInterval(verificarAcesso, 5 * 60 * 1000);
}

function pararVerificacaoAcesso() {
  if (acessoInterval) { clearInterval(acessoInterval); acessoInterval = null; }
}

function verificarAcesso() { /* DESATIVADO - acesso livre */ return; }