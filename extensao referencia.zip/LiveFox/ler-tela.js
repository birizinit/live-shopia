// "LER A TELA" (modo servidor-driven): a extensão lê o chat da live (content.js)
// e MANDA cada comentário pro SERVIDOR, que responde (tema/IA) e devolve a voz
// pelo SSE — o APP toca no cabo. A extensão aqui é só OUVIDOS; não decide nem fala.
// NÃO substitui nada do que a extensão já faz (monitor, vendas, violação, Áudio
// Infinito continuam). Script LIMPO (padrão guia.js). Expõe window.LFLerTela.
(function (g) {
  'use strict';
  const P = () => g.LFPainel;
  let ativo = false, hbTimer = null, lidos = 0;
  const ouvintes = new Set();
  const status = (ev) => { for (const fn of ouvintes) { try { fn(ev); } catch (e) {} } };

  function avisarAbas(action) {
    try {
      g.chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
        if (g.chrome.runtime.lastError) return;
        (tabs || []).forEach((t) => { try { g.chrome.tabs.sendMessage(t.id, { action }, () => { if (g.chrome.runtime.lastError) {} }); } catch (e) {} });
      });
    } catch (e) {}
  }

  // Assinatura caiu no meio: para de ler e manda a UI travar (tela "sem plano").
  function bloquear(motivo) {
    API.parar();
    status({ tipo: 'bloqueado', texto: motivo || 'assinatura inativa — renove para continuar' });
    try { g.LFAcesso && g.LFAcesso.rechecar(); } catch (e) {}
  }
  // Envia pro servidor e, se ele mandar parar (plano inativo), trava tudo.
  function enviar(nome, texto, tipo) {
    P().comentario(nome || 'amor', texto || '', tipo).then((r) => { if (r && r.parar) bloquear(r.motivo); }).catch(() => {});
  }

  // recebe o que o content.js leu na tela e repassa pro servidor
  if (g.chrome && g.chrome.runtime && g.chrome.runtime.onMessage) {
    g.chrome.runtime.onMessage.addListener((msg) => {
      if (!ativo || !msg || !P()) return;
      if (msg.action === 'liveComment') {
        lidos++;
        status({ tipo: 'lido', nome: msg.nome, texto: msg.texto, lidos });
        enviar(msg.nome, msg.texto, 'comentario');
      } else if (msg.action === 'liveEntry') {
        enviar(msg.nome, '', 'entrada');
      }
    });
  }

  const API = {
    estaAtivo: () => ativo,
    aoStatus(fn) { ouvintes.add(fn); return () => ouvintes.delete(fn); },

    async ativar() {
      if (ativo) return { ok: true, jaAtivo: true };
      if (!P() || !(await P().estaLogado())) { status({ tipo: 'erro', texto: 'faça login primeiro' }); return { ok: false, erro: 'login' }; }
      // TRAVA paid-only: sem plano ativo não começa a ler — abre a tela de assinar.
      const lic = await P().licenca().catch(() => ({ ativo: false }));
      if (!lic || !lic.ativo) {
        status({ tipo: 'erro', texto: lic && lic.motivo ? lic.motivo : 'assine um plano para usar' });
        try { g.LFAcesso && g.LFAcesso.travar(lic); } catch (e) {}
        return { ok: false, erro: 'plano' };
      }
      ativo = true; lidos = 0;
      avisarAbas('startChatWatch');
      await P().extHeartbeat().catch(() => {});
      clearInterval(hbTimer);
      hbTimer = setInterval(async () => { if (!ativo) return; const r = await P().extHeartbeat().catch(() => ({})); if (r && r.parar) bloquear(r.motivo); }, 15000);
      if (hbTimer.unref) hbTimer.unref();
      status({ tipo: 'ativo', texto: 'Lendo a tela — conectado ao app. Volte pro app pra ver e ouvir.', lidos: 0 });
      return { ok: true };
    },

    parar() {
      ativo = false;
      clearInterval(hbTimer); hbTimer = null;
      avisarAbas('stopChatWatch');
      status({ tipo: 'parado', texto: 'Leitura da tela desligada' });
      return { ok: true };
    },

    toggle() { return ativo ? this.parar() : this.ativar(); },
  };

  g.LFLerTela = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
