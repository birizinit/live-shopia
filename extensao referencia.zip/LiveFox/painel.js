// SDK do PAINEL para a extensão. Conecta login + gate + heartbeat.
// Funciona no navegador (usa chrome.storage.local) e é testável no Node
// (usa um storage em memória quando não há chrome). Endpoints já testados no painel.
(function (g) {
  'use strict';

  // Painel na nuvem (produção). Para desenvolvimento local, defina
  // window.LF_PAINEL_URL = 'http://localhost:3001' antes de carregar este SDK.
  const PAINEL_URL = g.LF_PAINEL_URL || 'https://livefox.com.br';

  // ---- storage: chrome.storage.local no navegador; objeto em memória no Node ----
  const mem = {};
  const temChrome = typeof g.chrome !== 'undefined' && g.chrome.storage && g.chrome.storage.local;
  const store = {
    async get(k) {
      if (temChrome) { const o = await g.chrome.storage.local.get(k); return o[k]; }
      return mem[k];
    },
    async set(k, v) {
      if (temChrome) return g.chrome.storage.local.set({ [k]: v });
      mem[k] = v;
    },
    async del(k) {
      if (temChrome) return g.chrome.storage.local.remove(k);
      delete mem[k];
    },
  };

  const uuid = () =>
    (g.crypto && g.crypto.randomUUID) ? g.crypto.randomUUID()
      : 'dev-' + Math.random().toString(36).slice(2) + Date.now().toString(36);

  let hbTimer = null;
  let onParar = () => {};   // callback quando o servidor manda encerrar (limite/queda)

  async function deviceId() {
    let id = await store.get('lf_device_id');
    if (!id) { id = uuid(); await store.set('lf_device_id', id); }
    return id;
  }

  async function req(path, body, jwt) {
    const resp = await g.fetch(PAINEL_URL + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) },
      body: JSON.stringify(body || {}),
    });
    const data = await resp.json().catch(() => ({}));
    return { code: resp.status, data };
  }

  const API = {
    PAINEL_URL,

    async login(usuario, senha) {
      const device_id = await deviceId();
      // origem:'ext' => a extensão tem slot de sessão PRÓPRIO; logar no app web não derruba
      // a extensão (e vice-versa). Só outra sessão de EXTENSÃO derruba esta.
      const { code, data } = await req('/api/login', { usuario, senha, device_id, origem: 'ext' });
      if (code !== 200) return { ok: false, erro: data.erro || 'falha no login' };
      await store.set('lf_jwt', data.token);
      await store.set('lf_user', data.usuario);
      return { ok: true, usuario: data.usuario };
    },

    async logout() {
      await API.encerrarLive();
      await store.del('lf_jwt'); await store.del('lf_user'); await store.del('lf_live_token');
    },

    async estaLogado() { return !!(await store.get('lf_jwt')); },
    async usuario() { return store.get('lf_user'); },
    async jwt() { return store.get('lf_jwt'); },
    async liveToken() { return store.get('lf_live_token'); },

    onParar(fn) { onParar = fn || (() => {}); },

    // Abre a live: pede autorização (gate paid-only + limite de contas) e liga o heartbeat.
    async autorizarLive(tiktok_user) {
      const jwt = await store.get('lf_jwt');
      if (!jwt) return { ok: false, erro: 'faça login primeiro' };
      const device_id = await deviceId();
      const { code, data } = await req('/api/live/autorizar', { device_id, tiktok_user }, jwt);
      if (code !== 200) return { ok: false, erro: data.erro || 'não autorizado' };
      await store.set('lf_live_token', data.live_token);
      await store.set('lf_session_id', data.session_id);
      ligarHeartbeat(data.heartbeat_s || 45);
      return { ok: true, live_token: data.live_token, restante_horas: data.restante_horas, plano: data.plano, recursos: data.recursos };
    },

    // Voz premium (ElevenLabs) gerada no painel — devolve o áudio em base64 pra tocar no cabo.
    async voz(texto, { idioma = 'pt-BR', voiceId, settings } = {}) {
      const jwt = await store.get('lf_jwt');
      const device_id = await deviceId();
      const { code, data } = await req('/api/voz', { texto, idioma, device_id, voiceId, settings }, jwt);
      return code === 200 ? { ok: true, audio_b64: data.audio_b64, mime: data.mime, chars: data.chars } : { ok: false, status: code, erro: data.erro };
    },

    // ---- Planos & checkout (Pix) ----
    async planos() {
      const r = await g.fetch(PAINEL_URL + '/api/planos');
      const d = await r.json().catch(() => ({}));
      return d.planos || {};
    },
    async criarPagamento(plano, documento) {
      const jwt = await store.get('lf_jwt');
      const { code, data } = await req('/api/pagamento/criar', { plano, document: documento }, jwt);
      return code === 200 ? { ok: true, ...data } : { ok: false, erro: data.erro || 'falha' };
    },
    async statusPagamento(external_id) {
      const jwt = await store.get('lf_jwt');
      const r = await g.fetch(PAINEL_URL + '/api/pagamento/' + encodeURIComponent(external_id), { headers: { Authorization: `Bearer ${jwt}` } });
      const d = await r.json().catch(() => ({}));
      return d.pagamento || null;
    },

    // ---- LICENÇA: "esta extensão pode rodar?" (fonte única da verdade) ----
    async licenca() {
      const jwt = await store.get('lf_jwt');
      if (!jwt) return { ativo: false, motivo: 'login', status: 'deslogado' };
      const device_id = await deviceId();
      try {
        const r = await g.fetch(PAINEL_URL + '/api/ext/licenca?device_id=' + encodeURIComponent(device_id), { headers: { Authorization: `Bearer ${jwt}` } });
        const d = await r.json().catch(() => ({}));
        if (r.status === 401) return { ativo: false, motivo: 'login', status: 'deslogado' };
        return d || { ativo: false, motivo: 'erro' };
      } catch { return { ativo: false, motivo: 'sem conexão com o servidor', status: 'offline' }; }
    },
    // URL do CHECKOUT no APP (mesmo fluxo/Simplify), já logado via token na URL.
    async checkoutUrl(planoId) {
      const jwt = await store.get('lf_jwt');
      let url = PAINEL_URL + '/estudio/planos';
      const q = [];
      if (jwt) q.push('token=' + encodeURIComponent(jwt));
      if (planoId) q.push('plano=' + encodeURIComponent(planoId));
      return url + (q.length ? '?' + q.join('&') : '');
    },
    // Abre o checkout do app numa nova aba (usado pela trava e pela aba "Planos").
    async abrirCheckout(planoId) {
      const url = await API.checkoutUrl(planoId);
      try { if (g.chrome && g.chrome.tabs) g.chrome.tabs.create({ url }); else g.open(url, '_blank'); }
      catch { g.open(url, '_blank'); }
    },
    // Abre qualquer rota do APP já logado (SSO por token). Ex.: abrirApp('') = início.
    async abrirApp(rota) {
      const jwt = await store.get('lf_jwt');
      let url = PAINEL_URL + '/estudio/' + (rota || '');
      if (jwt) url += (url.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(jwt);
      try { if (g.chrome && g.chrome.tabs) g.chrome.tabs.create({ url }); else g.open(url, '_blank'); }
      catch { g.open(url, '_blank'); }
    },

    // ---- Contas TikTok (limitadas pelo plano) ----
    async contas() {
      const jwt = await store.get('lf_jwt');
      const r = await g.fetch(PAINEL_URL + '/api/contas', { headers: { Authorization: `Bearer ${jwt}` } });
      const d = await r.json().catch(() => ({}));
      return { contas: d.contas || [], limite: d.limite || 1 };
    },
    async addConta(tiktok_user) {
      const jwt = await store.get('lf_jwt');
      const { code, data } = await req('/api/contas', { tiktok_user }, jwt);
      return code === 200 ? { ok: true, ...data } : { ok: false, erro: data.erro || 'falha' };
    },
    async delConta(id) {
      const jwt = await store.get('lf_jwt');
      const r = await g.fetch(PAINEL_URL + '/api/contas/' + encodeURIComponent(id), { method: 'DELETE', headers: { Authorization: `Bearer ${jwt}` } });
      const d = await r.json().catch(() => ({}));
      return { contas: d.contas || [], limite: d.limite || 1 };
    },

    // ---- Config de live do criador (temas/roteiro/toggles) ----
    // O servidor devolve os campos da config ESPALHADOS no topo (ok(res,{...config,recursos})),
    // não aninhados em `config`. Então separamos `ok`/`recursos` e o resto É a config.
    async getConfig() {
      const jwt = await store.get('lf_jwt');
      const r = await g.fetch(PAINEL_URL + '/api/config', { headers: { Authorization: `Bearer ${jwt}` } });
      const d = await r.json().catch(() => ({}));
      const { ok, erro, recursos, config: aninhada, ...topo } = d || {};
      // compat: aceita tanto o formato aninhado (antigo) quanto o espalhado (atual)
      const config = (aninhada && typeof aninhada === 'object') ? aninhada
        : (Object.keys(topo).length ? topo : null);
      return { config, recursos: recursos || null };
    },

    // "Ler a tela": a extensão manda cada comentário lido pro servidor, que responde
    // (tema/IA) e devolve a voz pelo SSE (o app toca no cabo). Modo servidor-driven.
    async comentario(nome, texto, tipo = 'comentario') {
      const jwt = await store.get('lf_jwt');
      const { code, data } = await req('/api/live/comentario', { nome, texto, tipo }, jwt);
      return code === 200 ? { ok: true, ...data } : { ok: false, status: code };
    },
    // Heartbeat "estou lendo a tela" — mantém a extensão ONLINE pro modal do app.
    async extHeartbeat() {
      const jwt = await store.get('lf_jwt');
      if (!jwt) return { ok: false };
      const { code } = await req('/api/live/ext-heartbeat', {}, jwt);
      return { ok: code === 200 };
    },

    // Resposta de comentário por IA (híbrido) — só o texto; a voz sai depois no /api/voz.
    async responder(comentario, { nome, produto, preco } = {}) {
      const jwt = await store.get('lf_jwt');
      const device_id = await deviceId();
      const { code, data } = await req('/api/live/responder', { comentario, nome, produto, preco, device_id }, jwt);
      return code === 200 ? { ok: true, resposta: data.resposta || null } : { ok: false, status: code, erro: data.erro };
    },
    async saveConfig(config) {
      const jwt = await store.get('lf_jwt');
      const { code, data } = await req('/api/config', { config }, jwt);
      return code === 200 ? { ok: true } : { ok: false, erro: data.erro || 'falha' };
    },

    // Fecha a live: para o heartbeat e avisa o servidor (acumula o último trecho).
    async encerrarLive() {
      if (hbTimer) { clearInterval(hbTimer); hbTimer = null; }
      const jwt = await store.get('lf_jwt');
      await store.del('lf_live_token');
      if (jwt) { try { await req('/api/live/encerrar', {}, jwt); } catch {} }
    },
  };

  function ligarHeartbeat(intervalo_s) {
    if (hbTimer) clearInterval(hbTimer);
    hbTimer = setInterval(async () => {
      try {
        const jwt = await store.get('lf_jwt');
        if (!jwt) return;
        const { code, data } = await req('/api/live/heartbeat', { session_id: await store.get('lf_session_id') }, jwt);
        if (code === 402 || data.parar) {           // limite estourou / assinatura caiu
          clearInterval(hbTimer); hbTimer = null;
          await store.del('lf_live_token');
          onParar(data.motivo || 'limite atingido');
        }
      } catch { /* rede instável: tenta no próximo tick */ }
    }, Math.max(10, intervalo_s) * 1000);
  }

  g.LFPainel = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
