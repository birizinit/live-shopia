// Guia "Como funciona" — abre/fecha o overlay e mostra 1x automaticamente.
// Script limpo (o sidebar.js é ofuscado; não mexemos nele). Só usa IDs próprios.
(function () {
  'use strict';
  function wire() {
    const ov = document.getElementById('lfGuiaOverlay');
    const btn = document.getElementById('lfGuiaBtn');
    if (!ov || !btn) return;
    const abrir = () => ov.classList.add('on');
    const fechar = () => { ov.classList.remove('on'); try { localStorage.setItem('lf_guia_v1', '1'); } catch {} };
    btn.addEventListener('click', abrir);
    document.getElementById('lfGuiaX')?.addEventListener('click', fechar);
    document.getElementById('lfGuiaOk')?.addEventListener('click', fechar);
    // clicar no fundo escuro (fora do card) fecha
    ov.addEventListener('click', (e) => { if (e.target === ov) fechar(); });
    // primeira vez: abre sozinho pra guiar quem chegou agora
    let visto = false; try { visto = localStorage.getItem('lf_guia_v1') === '1'; } catch {}
    if (!visto) setTimeout(abrir, 500);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();
