// Deixa a aba "Áudio" ciente do sistema: BlackHole no Mac, VB-Cable no Windows.
// O ROTEAMENTO já funciona nos dois (audio-cabo.js acha o cabo pelo nome —
// 'blackhole' está na lista). Isto aqui só ajusta as INSTRUÇÕES + o download.
// Script separado e limpo (o sidebar.js é ofuscado; não mexemos nele).
(function () {
  'use strict';
  const BASE = 'https://livefox.com.br';
  const ua = navigator.userAgent || '';
  const isMac = /Mac/i.test(ua) && !/iPhone|iPad|iPod/i.test(ua);

  function aplicar() {
    const set = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; };
    const dl = document.getElementById('caboDl');

    if (isMac) {
      set('caboNome', 'BlackHole');
      set('caboSub', 'Roteamento de áudio (Mac) para o Live Studio');
      set('caboS1', 'Instalar o BlackHole');
      set('caboS1d', 'Cabo de áudio virtual gratuito (Mac). Permite que o Chrome envie a voz da IA direto pro Live Studio.');
      if (dl) { dl.href = BASE + '/downloads/BlackHole-2ch.pkg'; dl.removeAttribute('target'); dl.setAttribute('download', ''); dl.innerHTML = '⬇️ Baixar BlackHole grátis'; }
      set('caboS2', 'Configurar o Mac');
      set('caboS2b', '1. Abra o <b style="color:var(--text)">BlackHole-2ch.pkg</b> e siga <b style="color:#ff6a00">Continuar → Instalar</b><br>2. Se pedir, digite a <b style="color:var(--text)">senha do Mac</b> (normal pra instalar áudio)<br>3. Pronto — a IA já manda a voz pro cabo sozinha');
      set('caboS3b', '1. <b style="color:var(--text)">TikTok Live Studio → Configurações → Áudio</b><br>2. Microfone → <b style="color:#ff6a00">BlackHole 2ch</b><br>3. Salve e volte pra live');
    } else if (dl) {
      // Windows: mantém as instruções, só aponta o download pro instalador hospedado.
      dl.href = BASE + '/downloads/VBCABLE.zip'; dl.removeAttribute('target'); dl.setAttribute('download', '');
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', aplicar);
  else aplicar();
})();
