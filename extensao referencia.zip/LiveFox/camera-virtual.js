// LIVE FOX — CÂMERA E MICROFONE VIRTUAIS (mundo MAIN, document_start)
//
// Substitui a webcam por um vídeo carregado pelo usuário e o microfone por um arquivo
// de áudio, com banner sobreposto. Tudo local: nenhum arquivo sai da máquina.
//
// Como funciona:
//   - navigator.mediaDevices.enumerateDevices ganha dois dispositivos nossos na lista;
//   - navigator.mediaDevices.getUserMedia devolve nossas tracks quando eles são escolhidos;
//   - o vídeo é desenhado num <canvas> (com o banner por cima) e capturado com
//     captureStream — é isso que vira a "câmera";
//   - o áudio passa por um grafo de Web Audio e sai num MediaStreamAudioDestinationNode —
//     é isso que vira o "microfone".
//
// Precisa rodar em document_start e no mundo MAIN: se o TikTok pegar
// navigator.mediaDevices antes, os hooks não valem mais.
//
// O gate de assinatura vive no camera-gate.js (mundo ISOLATED) e chega por postMessage.
(function () {
  'use strict';

  if (window.__lfCameraVirtual) return;
  window.__lfCameraVirtual = true;

  // ---------- IDs dos dispositivos falsos ----------
  // Fixos: o TikTok guarda o deviceId escolhido e reusa na próxima live.
  const DEV_VIDEO = 'lf-cam-virtual-video-0001';
  const DEV_AUDIO = 'lf-cam-virtual-audio-0001';
  const DEV_GRUPO = 'lf-cam-virtual-grupo-0001';
  const LABEL_VIDEO = 'Live Fox — Câmera Virtual (1080p)';
  const LABEL_AUDIO = 'Live Fox — Microfone Virtual';

  // ---------- Estado geral ----------
  let ativo = false;
  let liberado = false;            // o plano inclui CÂMERA VIRTUAL? (vem do gate)
  let audioLiberado = false;       // o plano inclui ÁUDIO DA LIVE (trechos + camada)?
  let motivoBloqueio = 'login';
  let urlCheckout = 'https://livefox.com.br/estudio/planos';

  let videoEl = null;
  let playlist = [];               // [{ url, nome }]
  let idxAtual = -1;
  let wakeLock = null;

  // ---------- Canvas (a "câmera") ----------
  let canvas = null, ctx = null, rafId = null;
  let canvasStream = null;
  // Dimensões/FPS agora mutáveis: "Modo leve" (PC fraco) baixa a resolução e o FPS
  // pra cortar o custo de ENCODE em tempo real (o que trava i3 com vídeo longo).
  let LARGURA = 1280, ALTURA = 720, FPS = 24;   // 24fps já alivia ~20% do encode (era 30)
  let modoLeve = false;

  // ---------- Áudio (o "microfone") ----------
  let audioCtx = null;
  let audioBuffer = null;          // arquivo do usuário decodificado
  let destino = null;              // MediaStreamAudioDestinationNode
  let ganhoMestre = null;
  let audioStream = null;
  let videoSrcNode = null;         // áudio EMBUTIDO do vídeo -> grafo (quando não há arquivo)
  let ganhoVideo = null;
  let fonteAtual = null;
  let engineLigada = false;
  let audioNome = '';

  // ---------- Trechos (áudio) ----------
  let trechosAtivo = false;
  let trMin = 4, trMax = 12, trPausa = 1;
  let trTimer = null;

  // ---------- Looping inteligente (vídeo) ----------
  let loopAtivo = false;
  let loopMin = 4, loopMax = 12, loopPausa = 1;
  let loopTimer = null;

  // ---------- Camada ao vivo (sons sintéticos) ----------
  let camadaAtiva = false;
  let clRuido = true, clRespira = true, clCliques = true, clVariacao = true;
  let clVolume = 0.11;
  let noRuido = null, gnRuido = null, filtroRuido = null;
  let timerRespira = null, timerCliques = null;
  let lfo = null, lfoGanho = null, ganhoVariacao = null;

  // ---------- Banner ----------
  let bannerImg = null, bannerNome = '';
  let bnEscala = 0.30, bnOpacidade = 1, bnX = 50, bnY = 85;

  // ---------- Sync / vigia ----------
  let autoSync = true, syncSegundos = 60, syncTimer = null;
  let vigia = null, ultimoTempo = -1;

  // Tracks que entregamos: precisamos reconhecê-las pra repor quando o consumidor as mata.
  const nossasTracks = new Set();
  const streamsEntregues = new Set();

  const rnd = (min, max) => min + Math.random() * (max - min);

  // ======================================================================
  //                     PERSISTÊNCIA (IndexedDB)
  // ======================================================================
  // chrome.storage.local não aguenta vídeo/áudio (limite pequeno e é JSON).
  // IndexedDB guarda ArrayBuffer direto e sobrevive a reload da página.
  const DB_NOME = 'livefox_camera';
  const DB_VER = 1;
  let dbConn = null;

  function abrirDB() {
    if (dbConn) return Promise.resolve(dbConn);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NOME, DB_VER);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('videos')) db.createObjectStore('videos');
        if (!db.objectStoreNames.contains('audio')) db.createObjectStore('audio');
        if (!db.objectStoreNames.contains('banner')) db.createObjectStore('banner');
        if (!db.objectStoreNames.contains('config')) db.createObjectStore('config');
      };
      req.onsuccess = () => { dbConn = req.result; resolve(dbConn); };
      req.onerror = () => reject(req.error);
    });
  }

  async function dbPut(store, chave, valor) {
    try {
      const db = await abrirDB();
      return new Promise((resolve) => {
        const tx = db.transaction(store, 'readwrite');
        tx.objectStore(store).put(valor, chave);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      });
    } catch (e) { return false; }
  }

  async function dbGet(store, chave) {
    try {
      const db = await abrirDB();
      return new Promise((resolve) => {
        const tx = db.transaction(store, 'readonly');
        const r = tx.objectStore(store).get(chave);
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => resolve(undefined);
      });
    } catch (e) { return undefined; }
  }

  async function dbLimpar(store) {
    try {
      const db = await abrirDB();
      return new Promise((resolve) => {
        const tx = db.transaction(store, 'readwrite');
        tx.objectStore(store).clear();
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      });
    } catch (e) { return false; }
  }

  async function dbTodasChaves(store) {
    try {
      const db = await abrirDB();
      return new Promise((resolve) => {
        const tx = db.transaction(store, 'readonly');
        const r = tx.objectStore(store).getAllKeys();
        r.onsuccess = () => resolve(r.result || []);
        r.onerror = () => resolve([]);
      });
    } catch (e) { return []; }
  }

  function salvarConfig() {
    dbPut('config', 'geral', {
      trechosAtivo, trMin, trMax, trPausa,
      loopAtivo, loopMin, loopMax, loopPausa,
      camadaAtiva, clRuido, clRespira, clCliques, clVariacao, clVolume,
      bnEscala, bnOpacidade, bnX, bnY,
      autoSync, syncSegundos, minimizado, modoLeve,
    });
  }

  async function carregarConfig() {
    const c = await dbGet('config', 'geral');
    if (!c || typeof c !== 'object') return;
    // Só sobrescreve o que realmente está salvo — config antiga (de uma versão com
    // menos campos) não pode zerar os defaults dos campos novos.
    const b = (v, def) => (typeof v === 'boolean' ? v : def);
    const n = (v, def) => (Number.isFinite(Number(v)) ? Number(v) : def);
    trechosAtivo = b(c.trechosAtivo, trechosAtivo);
    trMin = n(c.trMin, trMin); trMax = n(c.trMax, trMax); trPausa = n(c.trPausa, trPausa);
    loopAtivo = b(c.loopAtivo, loopAtivo);
    loopMin = n(c.loopMin, loopMin); loopMax = n(c.loopMax, loopMax); loopPausa = n(c.loopPausa, loopPausa);
    camadaAtiva = b(c.camadaAtiva, camadaAtiva);
    clRuido = b(c.clRuido, clRuido); clRespira = b(c.clRespira, clRespira);
    clCliques = b(c.clCliques, clCliques); clVariacao = b(c.clVariacao, clVariacao);
    clVolume = n(c.clVolume, clVolume);
    bnEscala = n(c.bnEscala, bnEscala); bnOpacidade = n(c.bnOpacidade, bnOpacidade);
    bnX = n(c.bnX, bnX); bnY = n(c.bnY, bnY);
    autoSync = b(c.autoSync, autoSync); syncSegundos = n(c.syncSegundos, syncSegundos);
    minimizado = b(c.minimizado, minimizado);
    modoLeve = b(c.modoLeve, modoLeve);
    aplicarQualidade();   // aplica as dimensões/FPS do modo salvo (canvas ainda nem existe: só ajusta os alvos)
  }

  // ======================================================================
  //                     CANVAS — o vídeo vira "câmera"
  // ======================================================================
  function criarCanvas() {
    if (canvas) return canvas;
    canvas = document.createElement('canvas');
    canvas.width = LARGURA; canvas.height = ALTURA;
    ctx = canvas.getContext('2d', { alpha: false });
    return canvas;
  }

  // Encaixa o vídeo no canvas sem distorcer (letterbox), como uma webcam faria.
  function calcEncaixe(vw, vh) {
    if (!vw || !vh) return { x: 0, y: 0, w: LARGURA, h: ALTURA };
    const escala = Math.min(LARGURA / vw, ALTURA / vh);
    const w = vw * escala, h = vh * escala;
    return { x: (LARGURA - w) / 2, y: (ALTURA - h) / 2, w, h };
  }

  // Throttle a ~FPS: o rAF chama a ~60fps, mas o stream captura a FPS. Desenhar a 60
  // era 2x trabalho de GPU/CPU à toa. Usamos o timestamp do próprio rAF (sem Date.now).
  let _lastDraw = 0;
  function desenharQuadro(ts) {
    rafId = requestAnimationFrame(desenharQuadro);
    if (typeof ts === 'number') {
      if (ts - _lastDraw < (1000 / FPS)) return;
      _lastDraw = ts;
    }
    if (!ctx) return;
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, LARGURA, ALTURA);
    if (videoEl && videoEl.readyState >= 2) {
      const e = calcEncaixe(videoEl.videoWidth, videoEl.videoHeight);
      try { ctx.drawImage(videoEl, e.x, e.y, e.w, e.h); } catch (err) {}
    }
    // Banner é desenhado DENTRO do canvas: assim ele vai na transmissão,
    // não fica só como enfeite na tela de quem está gravando.
    if (bannerImg && bannerImg.complete && bannerImg.naturalWidth) {
      const lw = LARGURA * bnEscala;
      const lh = (bannerImg.naturalHeight / bannerImg.naturalWidth) * lw;
      const lx = (bnX / 100) * LARGURA - lw / 2;
      const ly = (bnY / 100) * ALTURA - lh / 2;
      const alphaAntes = ctx.globalAlpha;
      ctx.globalAlpha = bnOpacidade;
      try { ctx.drawImage(bannerImg, lx, ly, lw, lh); } catch (err) {}
      ctx.globalAlpha = alphaAntes;
    }
  }

  function ligarDesenho() { if (!rafId) { criarCanvas(); desenharQuadro(); } }
  function pararDesenho() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }

  function pegarStreamCanvas() {
    criarCanvas(); ligarDesenho();
    if (!canvasStream || !canvasStream.getVideoTracks().length ||
        canvasStream.getVideoTracks()[0].readyState === 'ended') {
      canvasStream = canvas.captureStream(FPS);
    }
    return canvasStream;
  }

  // ======================================================================
  //                     HOOKS — getUserMedia / enumerateDevices
  // ======================================================================
  const md = navigator.mediaDevices;
  if (!md || !md.getUserMedia) return;   // página sem suporte: não faz nada
  const gumOriginal = md.getUserMedia.bind(md);
  const enumOriginal = md.enumerateDevices.bind(md);

  // O deviceId pedido pode vir como string, array ou {exact|ideal}.
  function idPedido(c) {
    if (!c || typeof c !== 'object') return null;
    const d = c.deviceId;
    if (!d) return null;
    if (typeof d === 'string') return d;
    if (Array.isArray(d)) return d[0] || null;
    if (typeof d === 'object') {
      const v = d.exact !== undefined ? d.exact : d.ideal;
      return Array.isArray(v) ? v[0] : (v || null);
    }
    return null;
  }

  // Cada consumidor recebe um CLONE. Se ele parar a track dele, não derruba os outros.
  function novoClone(tipo) {
    try {
      const s = tipo === 'video' ? pegarStreamCanvas() : audioStream;
      if (!s) return null;
      const t = (tipo === 'video' ? s.getVideoTracks() : s.getAudioTracks())[0];
      if (!t || t.readyState === 'ended') return null;
      const c = t.clone();
      nossasTracks.add(c);
      return c;
    } catch (e) { return null; }
  }

  md.getUserMedia = async function (constraints) {
    if (!ativo || !liberado) return gumOriginal(constraints);
    const saida = new MediaStream();
    let usouNosso = false, usouVideoNosso = false;

    if (constraints && constraints.video) {
      const id = idPedido(constraints.video);
      const t = (!id || id === DEV_VIDEO) ? novoClone('video') : null;
      if (t) { saida.addTrack(t); usouNosso = true; usouVideoNosso = true; }
      else {
        try { (await gumOriginal({ video: constraints.video })).getVideoTracks().forEach((x) => saida.addTrack(x)); }
        catch (e) {}
      }
    }

    if (constraints && constraints.audio) {
      const id = idPedido(constraints.audio);
      // Escolheu nossa câmera? O áudio vai junto, mesmo que o mic selecionado seja outro —
      // senão a live sai com vídeo gravado e microfone real, que é o pior dos mundos.
      const forcar = usouVideoNosso && audioStream;
      const t = (!id || id === DEV_AUDIO || forcar) ? novoClone('audio') : null;
      if (t) { saida.addTrack(t); usouNosso = true; }
      else {
        if (id === DEV_AUDIO && !audioStream) aviso('⚠️ Nenhum áudio carregado no Live Fox.');
        try { (await gumOriginal({ audio: constraints.audio })).getAudioTracks().forEach((x) => saida.addTrack(x)); }
        catch (e) {}
      }
    }

    // Pediu só vídeo mas temos áudio: manda junto (o TikTok às vezes pede em duas etapas).
    if (usouVideoNosso && (!constraints || !constraints.audio) && audioStream) {
      const t = novoClone('audio');
      if (t) { saida.addTrack(t); usouNosso = true; }
    }

    if (usouNosso) { streamsEntregues.add(saida); aviso('🔴 No ar — transmitindo.'); }
    return saida;
  };

  md.enumerateDevices = async function () {
    const reais = await enumOriginal();
    if (!ativo || !liberado) return reais;
    const mk = (deviceId, kind, label) => ({
      deviceId, kind, label, groupId: DEV_GRUPO,
      toJSON() { return { deviceId, kind, label, groupId: DEV_GRUPO }; },
    });
    return [
      mk(DEV_VIDEO, 'videoinput', LABEL_VIDEO),
      mk(DEV_AUDIO, 'audioinput', LABEL_AUDIO),
      ...reais,
    ];
  };

  // Se o consumidor encerrou uma track nossa, repõe na hora — senão a live congela.
  function reporTracks() {
    for (const s of streamsEntregues) {
      for (const tipo of ['video', 'audio']) {
        const atuais = tipo === 'video' ? s.getVideoTracks() : s.getAudioTracks();
        const mortas = atuais.filter((t) => nossasTracks.has(t) && t.readyState === 'ended');
        if (!mortas.length) continue;
        mortas.forEach((t) => { s.removeTrack(t); nossasTracks.delete(t); });
        const nova = novoClone(tipo);
        if (nova) s.addTrack(nova);
      }
    }
  }

  // Trocar de vídeo NÃO invalida o stream: o canvas é sempre o mesmo e o loop de desenho
  // continua. Só garantimos que ele existe e repomos track que o consumidor tenha matado.
  function recapturar() {
    try { pegarStreamCanvas(); reporTracks(); } catch (e) {}
  }

  // Aplica a qualidade da câmera (normal x modo leve). Modo leve = 480p/20fps: bem menos
  // ENCODE em tempo real, que é o que trava i3 com vídeo longo + tudo ligado.
  function aplicarQualidade() {
    if (modoLeve) { LARGURA = 854; ALTURA = 480; FPS = 20; }
    else          { LARGURA = 1280; ALTURA = 720; FPS = 24; }
    if (canvas) { canvas.width = LARGURA; canvas.height = ALTURA; }
    // Descarta o track antigo (na resolução velha) e recaptura na nova.
    if (canvasStream) {
      try { canvasStream.getVideoTracks().forEach((t) => t.stop()); } catch (e) {}
      canvasStream = null;
    }
    if (ativo) recapturar();
  }

  // ======================================================================
  //                     ÁUDIO — o arquivo vira "microfone"
  // ======================================================================
  function iniciarCtx() {
    if (audioCtx) return audioCtx;
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    ganhoMestre = audioCtx.createGain();
    ganhoVariacao = audioCtx.createGain();
    destino = audioCtx.createMediaStreamDestination();
    ganhoMestre.connect(ganhoVariacao);
    ganhoVariacao.connect(destino);
    audioStream = destino.stream;
    return audioCtx;
  }

  async function carregarAudio(file) {
    // Trava de servidor, não só de UI: mesmo que alguém habilite o input no DevTools,
    // sem o recurso no plano o áudio não carrega.
    if (!audioLiberado) { aviso('🔒 Seu plano não inclui o áudio da live.'); return; }
    iniciarCtx();
    const buf = await file.arrayBuffer();
    audioBuffer = await audioCtx.decodeAudioData(buf.slice(0));
    audioNome = file.name;
    dbPut('audio', 'arquivo', { buf, nome: file.name, tipo: file.type });
    ligarAudio();
    aviso('🎧 Áudio carregado: ' + file.name);
  }

  // Toca o arquivo inteiro em loop (modo simples).
  function tocarContinuo() {
    if (!audioBuffer) return;
    pararFonte();
    const src = audioCtx.createBufferSource();
    src.buffer = audioBuffer;
    src.loop = true;
    src.connect(ganhoMestre);
    src.start(0);
    fonteAtual = src;
  }

  // Modo TRECHOS: toca um pedaço aleatório, dá uma pausa, toca outro. Evita o
  // padrão audível de um loop inteiro repetindo sempre igual.
  function tocarTrecho() {
    if (!audioBuffer || !trechosAtivo) return;
    pararFonte();
    const total = audioBuffer.duration;
    const dur = Math.min(rnd(trMin, trMax), total);
    const inicio = rnd(0, Math.max(0, total - dur));
    const src = audioCtx.createBufferSource();
    src.buffer = audioBuffer;
    src.connect(ganhoMestre);
    src.start(0, inicio, dur);
    fonteAtual = src;
    trTimer = setTimeout(() => {
      if (trechosAtivo && engineLigada) trTimer = setTimeout(tocarTrecho, trPausa * 1000);
    }, dur * 1000);
  }

  function pararFonte() {
    if (trTimer) { clearTimeout(trTimer); trTimer = null; }
    if (fonteAtual) { try { fonteAtual.stop(); } catch (e) {} try { fonteAtual.disconnect(); } catch (e) {} fonteAtual = null; }
  }

  function ligarAudio() {
    if (!audioBuffer) return;
    iniciarCtx();
    if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    silenciarAudioDoVideo();   // arquivo separado assume: silencia o áudio do vídeo
    engineLigada = true;
    if (trechosAtivo) tocarTrecho(); else tocarContinuo();
    if (camadaAtiva) ligarCamada();
  }

  function pararAudio() {
    engineLigada = false;
    pararFonte();
    pararCamada();
  }

  // ÁUDIO EMBUTIDO DO VÍDEO: quando NÃO há arquivo de áudio separado, o som do próprio
  // vídeo (ex.: um vídeo de 3h já com áudio) é roteado pro mesmo "microfone" virtual.
  // Antes o vídeo ficava muted e esse áudio era jogado fora.
  function ligarAudioDoVideo() {
    if (!audioLiberado || !videoEl) return;
    iniciarCtx();
    if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    if (!videoSrcNode) {
      // createMediaElementSource só pode ser chamado UMA vez por elemento.
      try { videoSrcNode = audioCtx.createMediaElementSource(videoEl); }
      catch (e) { return; }
      ganhoVideo = audioCtx.createGain();
      videoSrcNode.connect(ganhoVideo);
      ganhoVideo.connect(ganhoMestre);
    }
    // muted=true zera o MediaElementSource no Chrome. Como o grafo NÃO liga nas caixas
    // (só no destino do stream), não sai som local — vai só pra transmissão.
    videoEl.muted = false;
    ganhoVideo.gain.value = 1;
    engineLigada = true;
    if (camadaAtiva) ligarCamada();
    recapturar(); // anexa a faixa de áudio (agora com o som do vídeo) ao stream da câmera
  }

  // Quando um arquivo de áudio separado assume, silencia o áudio do vídeo (o arquivo vence).
  function silenciarAudioDoVideo() {
    if (ganhoVideo) ganhoVideo.gain.value = 0;
    if (videoEl) videoEl.muted = true;
  }

  // ======================================================================
  //                     CAMADA AO VIVO — sons sintéticos
  // ======================================================================
  // Ruído rosa suave = "sala com alguém dentro". Gerado, não gravado: não repete.
  function bufferRuido(segundos) {
    const sr = audioCtx.sampleRate;
    const buf = audioCtx.createBuffer(1, Math.floor(sr * segundos), sr);
    const d = buf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < d.length; i++) {
      const branco = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + branco * 0.0990460;
      b1 = 0.96300 * b1 + branco * 0.2965164;
      b2 = 0.57000 * b2 + branco * 1.0526913;
      d[i] = (b0 + b1 + b2 + branco * 0.1848) * 0.05;
    }
    return buf;
  }

  function ligarRuido() {
    if (noRuido || !clRuido) return;
    noRuido = audioCtx.createBufferSource();
    noRuido.buffer = bufferRuido(4);
    noRuido.loop = true;
    filtroRuido = audioCtx.createBiquadFilter();
    filtroRuido.type = 'lowpass';
    filtroRuido.frequency.value = 1400;
    gnRuido = audioCtx.createGain();
    gnRuido.gain.value = clVolume;
    noRuido.connect(filtroRuido); filtroRuido.connect(gnRuido); gnRuido.connect(ganhoMestre);
    noRuido.start(0);
  }

  function pararRuido() {
    if (noRuido) { try { noRuido.stop(); } catch (e) {} try { noRuido.disconnect(); } catch (e) {} noRuido = null; }
    if (filtroRuido) { try { filtroRuido.disconnect(); } catch (e) {} filtroRuido = null; }
    if (gnRuido) { try { gnRuido.disconnect(); } catch (e) {} gnRuido = null; }
  }

  // Respiração: envelope curto de ruído filtrado, em intervalo irregular.
  function respirar() {
    if (!audioCtx || !clRespira) return;
    const dur = rnd(0.35, 0.7);
    const src = audioCtx.createBufferSource();
    src.buffer = bufferRuido(dur);
    const f = audioCtx.createBiquadFilter();
    f.type = 'bandpass'; f.frequency.value = rnd(500, 900); f.Q.value = 0.8;
    const g = audioCtx.createGain();
    const agora = audioCtx.currentTime;
    g.gain.setValueAtTime(0, agora);
    g.gain.linearRampToValueAtTime(clVolume * rnd(1.1, 1.8), agora + dur * 0.35);
    g.gain.linearRampToValueAtTime(0, agora + dur);
    src.connect(f); f.connect(g); g.connect(ganhoMestre);
    src.start(agora); src.stop(agora + dur + 0.05);
  }

  function ligarRespiracoes() {
    if (timerRespira || !clRespira) return;
    const agendar = () => {
      timerRespira = setTimeout(() => { respirar(); agendar(); }, rnd(4000, 11000));
    };
    agendar();
  }
  function pararRespiracoes() { if (timerRespira) { clearTimeout(timerRespira); timerRespira = null; } }

  // Clique de mouse/teclado: transiente muito curto e agudo.
  function clicar() {
    if (!audioCtx || !clCliques) return;
    const dur = 0.02;
    const src = audioCtx.createBufferSource();
    src.buffer = bufferRuido(dur);
    const f = audioCtx.createBiquadFilter();
    f.type = 'highpass'; f.frequency.value = 2200;
    const g = audioCtx.createGain();
    const agora = audioCtx.currentTime;
    g.gain.setValueAtTime(clVolume * rnd(0.8, 1.5), agora);
    g.gain.exponentialRampToValueAtTime(0.0001, agora + dur);
    src.connect(f); f.connect(g); g.connect(ganhoMestre);
    src.start(agora); src.stop(agora + dur + 0.01);
  }

  function ligarCliques() {
    if (timerCliques || !clCliques) return;
    const agendar = () => {
      timerCliques = setTimeout(() => { clicar(); agendar(); }, rnd(7000, 22000));
    };
    agendar();
  }
  function pararCliques() { if (timerCliques) { clearTimeout(timerCliques); timerCliques = null; } }

  // Variação de mic: LFO lento no ganho — simula a pessoa se mexendo perto do microfone.
  function ligarVariacao() {
    if (lfo || !clVariacao || !ganhoVariacao) return;
    lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.07;
    lfoGanho = audioCtx.createGain();
    lfoGanho.gain.value = 0.06;          // ±6% no volume
    lfo.connect(lfoGanho); lfoGanho.connect(ganhoVariacao.gain);
    lfo.start(0);
  }
  function pararVariacao() {
    if (lfo) { try { lfo.stop(); } catch (e) {} try { lfo.disconnect(); } catch (e) {} lfo = null; }
    if (lfoGanho) { try { lfoGanho.disconnect(); } catch (e) {} lfoGanho = null; }
    if (ganhoVariacao) ganhoVariacao.gain.value = 1;
  }

  function ligarCamada() {
    if (!audioCtx || !audioLiberado) return;
    ligarRuido(); ligarRespiracoes(); ligarCliques(); ligarVariacao();
  }
  function pararCamada() {
    pararRuido(); pararRespiracoes(); pararCliques(); pararVariacao();
  }
  function atualizarVolumeCamada() { if (gnRuido) gnRuido.gain.value = clVolume; }

  // ======================================================================
  //                     BANNER
  // ======================================================================
  async function carregarBanner(file) {
    const buf = await file.arrayBuffer();
    const url = URL.createObjectURL(new Blob([buf], { type: file.type || 'image/png' }));
    await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => { bannerImg = img; bannerNome = file.name; resolve(); };
      img.onerror = () => resolve();
      img.src = url;
    });
    dbPut('banner', 'arquivo', { buf, nome: file.name, tipo: file.type });
    aviso('🖼️ Banner carregado: ' + file.name);
  }

  function removerBanner() {
    bannerImg = null; bannerNome = '';
    dbLimpar('banner');
    aviso('Banner removido.');
  }

  // ======================================================================
  //                     PLAYLIST / SYNC / VIGIA
  // ======================================================================
  function criarVideoEl() {
    if (videoEl) return videoEl;
    videoEl = document.createElement('video');
    videoEl.muted = true;            // o áudio da live vem do arquivo separado
    videoEl.playsInline = true;
    videoEl.loop = false;
    videoEl.style.display = 'none';
    (document.body || document.documentElement).appendChild(videoEl);
    videoEl.addEventListener('ended', () => proximo());
    return videoEl;
  }

  async function addVideos(files) {
    for (const f of files) {
      const buf = await f.arrayBuffer();
      const url = URL.createObjectURL(new Blob([buf], { type: f.type || 'video/mp4' }));
      const i = playlist.length;
      // Guarda o buffer junto: `removerVideo` reindexa o IndexedDB e precisa
      // reescrever os que ficaram — sem isto eles sumiriam no próximo reload.
      playlist.push({ url, nome: f.name, _buf: buf, _tipo: f.type });
      dbPut('videos', i, { buf, nome: f.name, tipo: f.type });
    }
    renderPlaylist();
    if (idxAtual === -1 && playlist.length) tocar(0);
  }

  async function tocar(i) {
    if (!playlist[i]) return;
    criarVideoEl();
    idxAtual = i;
    pararLoopVideo();
    videoEl.src = playlist[i].url;
    videoEl.load();
    try { await videoEl.play(); }
    catch (e) { try { await videoEl.play(); } catch (e2) { aviso('❌ Não consegui tocar o vídeo.'); return; } }
    ativo = true;
    recapturar();
    ligarVigia();
    pedirWakeLock();
    if (loopAtivo) ligarLoopVideo();
    if (audioBuffer && !engineLigada) ligarAudio();
    else if (!audioBuffer) ligarAudioDoVideo();  // sem arquivo separado -> usa o áudio embutido do vídeo
    // Avisa a página que a lista de dispositivos mudou — o TikTok recarrega o seletor.
    try { md.dispatchEvent(new Event('devicechange')); } catch (e) {}
    renderPlaylist(); renderEstado();
    aviso('✅ Câmera virtual pronta. Selecione "' + LABEL_VIDEO + '" no TikTok.');
  }

  function proximo() {
    if (!playlist.length) return;
    if (loopAtivo) { ligarLoopVideo(); return; }
    if (playlist.length === 1) { videoEl.currentTime = 0; videoEl.play().catch(() => {}); return; }
    tocar((idxAtual + 1) % playlist.length);
  }

  function removerVideo(i) {
    try { URL.revokeObjectURL(playlist[i].url); } catch (e) {}
    playlist.splice(i, 1);
    dbLimpar('videos').then(() => playlist.forEach((p, idx) => {
      if (p._buf) dbPut('videos', idx, { buf: p._buf, nome: p.nome, tipo: p._tipo || 'video/mp4' });
    }));
    if (i === idxAtual) { idxAtual = -1; if (playlist.length) tocar(Math.min(i, playlist.length - 1)); else desligar(); }
    else if (i < idxAtual) idxAtual--;
    renderPlaylist();
  }

  // Looping inteligente: pula pra um trecho aleatório do vídeo em vez de rodar
  // do começo ao fim sempre igual.
  function ligarLoopVideo() {
    pararLoopVideo();
    if (!videoEl || !videoEl.duration || !loopAtivo) return;
    tocarTrechoVideo();
  }
  function pararLoopVideo() { if (loopTimer) { clearTimeout(loopTimer); loopTimer = null; } }

  function tocarTrechoVideo() {
    if (!loopAtivo || !videoEl || !videoEl.duration) return;
    const total = videoEl.duration;
    const dur = Math.min(rnd(loopMin, loopMax), total);
    videoEl.currentTime = rnd(0, Math.max(0, total - dur));
    if (videoEl.paused) videoEl.play().catch(() => {});
    loopTimer = setTimeout(() => {
      if (!loopAtivo) return;
      loopTimer = setTimeout(() => { if (loopAtivo) tocarTrechoVideo(); }, loopPausa * 1000);
    }, dur * 1000);
  }

  // Micro-seek periódico: corrige drift entre o vídeo e o que o encoder está lendo.
  function ressincronizar(manual) {
    if (!videoEl || !videoEl.src || !videoEl.duration) return;
    try { videoEl.currentTime = Math.min(videoEl.duration - 0.05, videoEl.currentTime + 0.06); } catch (e) {}
    if (videoEl.paused) videoEl.play().catch(() => {});
    if (manual) aviso('🔁 Sincronizado.');
  }

  function reprogramarSync() {
    if (syncTimer) { clearInterval(syncTimer); syncTimer = null; }
    if (autoSync && syncSegundos > 0) {
      syncTimer = setInterval(() => {
        if (ativo && videoEl && !videoEl.paused && videoEl.src) ressincronizar(false);
      }, syncSegundos * 1000);
    }
  }

  // Vigia: vídeo travado (currentTime parado) volta a tocar sozinho.
  function ligarVigia() {
    if (vigia) return;
    vigia = setInterval(() => {
      if (!ativo || !videoEl || !videoEl.src || videoEl.paused || videoEl.ended) return;
      if (videoEl.currentTime === ultimoTempo) { try { videoEl.play().catch(() => {}); } catch (e) {} }
      ultimoTempo = videoEl.currentTime;
    }, 3000);
  }

  // Vigia das tracks: o consumidor (ou o próprio TikTok, ao trocar de layout) às vezes
  // encerra a track que entregamos. Sem repor, a live congela na hora e o usuário não
  // tem como saber por quê. Confere VÍDEO e ÁUDIO — antes só o áudio era vigiado, e a
  // reposição do vídeo só acontecia se a pessoa trocasse de vídeo na mão.
  setInterval(() => {
    if (!ativo) return;

    // Fonte do áudio morreu: reconstrói o grafo antes de repor nos consumidores.
    if (audioStream) {
      const t = audioStream.getAudioTracks()[0];
      if (t && t.readyState === 'ended') {
        iniciarCtx(); ligarAudio();
        aviso('🔊 Microfone virtual reconectado.');
      }
    }

    // Alguma track ENTREGUE morreu? Repõe (o novoClone já recria a fonte se preciso).
    let precisaRepor = false;
    for (const s of streamsEntregues) {
      if (s.getTracks().some((t) => nossasTracks.has(t) && t.readyState === 'ended')) { precisaRepor = true; break; }
    }
    if (precisaRepor) { reporTracks(); aviso('🔄 Transmissão restabelecida.'); }
  }, 2000);

  async function pedirWakeLock() {
    try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
  }

  document.addEventListener('visibilitychange', () => {
    if (ativo && document.visibilityState === 'visible') {
      pedirWakeLock();
      if (videoEl && videoEl.paused && videoEl.src) videoEl.play().catch(() => {});
    }
  });

  function ligar() {
    if (!liberado) return travaAssinatura();
    if (playlist.length) tocar(idxAtual >= 0 ? idxAtual : 0);
    else { aviso('Adicione um vídeo primeiro.'); const el = $('lfcv-arquivo'); if (el) el.click(); }
  }

  function desligar() {
    ativo = false;
    pararDesenho();
    pararLoopVideo();
    pararAudio();
    if (videoEl) { try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {} }
    if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
    canvasStream = null;
    try { md.dispatchEvent(new Event('devicechange')); } catch (e) {}
    renderEstado(); renderPlaylist();
    aviso('Câmera virtual desligada.');
  }

  // ======================================================================
  //                     INTERFACE (painel flutuante)
  // ======================================================================
  const $ = (id) => document.getElementById(id);
  // Nasce RECOLHIDO: o content script casa com todo tiktok.com, e um painel aberto no
  // feed/perfil seria só estorvo. Fica uma barrinha; a escolha do usuário é lembrada.
  let raiz = null, corpo = null, minimizado = true;

  function aviso(txt) {
    const el = $('lfcv-status');
    if (el) el.textContent = txt;
  }

  function travaAssinatura() {
    const map = {
      login: 'Faça login no Live Fox para usar a câmera virtual.',
      camera_fora_do_plano: 'Seu plano não inclui a câmera virtual — veja os planos que incluem.',
      'sem conexão com o servidor': 'Sem conexão com o servidor — tente de novo.',
    };
    aviso('🔒 ' + (map[motivoBloqueio] || motivoBloqueio || 'Recurso disponível nos planos pagos.'));
    renderEstado();
  }

  // Bloqueio POR RECURSO: o "Áudio da Live" (trechos + camada ao vivo) é liberado por
  // um recurso próprio do plano, separado da câmera. Quem tem só o plano de áudio usa
  // essa parte; quem não tem plano nenhum não usa nada.
  function renderRecursos() {
    const secoes = [
      ['lfcv-addaudio', audioLiberado], ['lfcv-trechos', audioLiberado],
      ['lfcv-trmin', audioLiberado], ['lfcv-trmax', audioLiberado], ['lfcv-trpausa', audioLiberado],
      ['lfcv-camada', audioLiberado], ['lfcv-clruido', audioLiberado], ['lfcv-clresp', audioLiberado],
      ['lfcv-clcliq', audioLiberado], ['lfcv-clvar', audioLiberado], ['lfcv-clvol', audioLiberado],
    ];
    for (const [id, ok] of secoes) {
      const el = $(id);
      if (!el) continue;
      el.disabled = !ok;
      el.style.opacity = ok ? '' : '.45';
      el.style.cursor = ok ? '' : 'not-allowed';
    }
    const av = $('lfcv-audionome');
    if (av && !audioLiberado) { av.textContent = '🔒 Áudio da live não incluso no seu plano'; av.className = 'lfcv-vazio'; }
  }

  const CSS = `
  #lfcv-raiz{position:fixed;z-index:2147483600;top:80px;right:20px;width:310px;
    font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
    background:#12141c;color:#e8eaf0;border:1px solid #262a38;border-radius:12px;
    box-shadow:0 12px 40px rgba(0,0,0,.55);overflow:hidden;user-select:none}
  #lfcv-cab{display:flex;align-items:center;gap:8px;padding:9px 11px;background:#121724;
    border-bottom:1px solid #262a38;cursor:move}
  #lfcv-cab b{flex:1;font-size:13px;letter-spacing:.2px}
  #lfcv-cab button{background:none;border:none;color:#9aa3b8;cursor:pointer;padding:2px 5px;
    border-radius:5px;font-size:15px;line-height:1}
  #lfcv-cab button:hover{background:#222633;color:#fff}
  #lfcv-corpo{padding:11px;max-height:70vh;overflow-y:auto}
  .lfcv-sec{border:1px solid #232735;border-radius:9px;margin-bottom:9px;overflow:hidden}
  .lfcv-sec>summary{padding:8px 10px;background:#121724;cursor:pointer;font-weight:600;
    font-size:12.5px;list-style:none}
  .lfcv-sec>summary::-webkit-details-marker{display:none}
  .lfcv-sec>div{padding:9px 10px}
  .lfcv-lin{display:flex;align-items:center;gap:7px;margin-bottom:7px}
  .lfcv-lin:last-child{margin-bottom:0}
  .lfcv-lin label{flex:1;font-size:12px;color:#b9c0d0}
  .lfcv-lin input[type=number]{width:52px}
  #lfcv-corpo input[type=number],#lfcv-corpo input[type=text]{background:#0A0E1A;border:1px solid #2a2f3f;
    color:#e8eaf0;border-radius:6px;padding:4px 6px;font-size:12px}
  #lfcv-corpo input[type=range]{flex:1;accent-color:#FF2E97}
  #lfcv-corpo input[type=checkbox]{accent-color:#FF2E97;width:15px;height:15px}
  .lfcv-btn{display:block;width:100%;padding:9px;border:none;border-radius:8px;cursor:pointer;
    font-weight:700;font-size:13px;background:#FF2E97;color:#fff;margin-bottom:8px}
  .lfcv-btn:hover{filter:brightness(1.08)}
  .lfcv-btn.off{background:#2a2f3f;color:#e8eaf0}
  .lfcv-btn.sec{background:#1d212d;color:#c8cede;font-weight:600;padding:7px;font-size:12px}
  #lfcv-status{font-size:11.5px;color:#8f97ab;padding:7px 2px 2px;min-height:16px;line-height:1.35}
  .lfcv-item{display:flex;align-items:center;gap:6px;padding:5px 7px;background:#0A0E1A;
    border-radius:6px;margin-bottom:4px;font-size:11.5px}
  .lfcv-item span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .lfcv-item.on{outline:1px solid #FF2E97}
  .lfcv-item button{background:none;border:none;color:#7d8598;cursor:pointer;font-size:13px}
  .lfcv-vazio{color:#6d748a;font-size:11.5px;text-align:center;padding:7px}
  .lfcv-dica{color:#6d748a;font-size:11px;margin-top:5px;line-height:1.4}
  `;

  function montarUI() {
    if (raiz) return;
    const st = document.createElement('style');
    st.textContent = CSS;
    document.head.appendChild(st);

    raiz = document.createElement('div');
    raiz.id = 'lfcv-raiz';
    raiz.innerHTML = `
      <div id="lfcv-cab">
        <b>🦊 Live Fox — Câmera Virtual</b>
        <button id="lfcv-min" title="Minimizar">–</button>
      </div>
      <div id="lfcv-corpo">
        <button class="lfcv-btn off" id="lfcv-toggle">Ligar câmera virtual</button>
        <div id="lfcv-status">Carregando…</div>

        <details class="lfcv-sec" open>
          <summary>🎬 Vídeos</summary>
          <div>
            <div id="lfcv-lista"></div>
            <button class="lfcv-btn sec" id="lfcv-add">+ Adicionar vídeo</button>
            <input type="file" id="lfcv-arquivo" accept="video/*" multiple hidden>
            <div class="lfcv-lin" style="margin-top:6px">
              <button class="lfcv-btn sec" id="lfcv-prev" style="margin:0">⏪ 10s</button>
              <button class="lfcv-btn sec" id="lfcv-next" style="margin:0">10s ⏩</button>
              <button class="lfcv-btn sec" id="lfcv-sync" style="margin:0">🔁</button>
            </div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>🔀 Looping inteligente (vídeo)</summary>
          <div>
            <div class="lfcv-lin"><label>Ativar</label><input type="checkbox" id="lfcv-loop"></div>
            <div class="lfcv-lin"><label>Trecho mín. (s)</label><input type="number" id="lfcv-loopmin" min="1" max="120"></div>
            <div class="lfcv-lin"><label>Trecho máx. (s)</label><input type="number" id="lfcv-loopmax" min="1" max="300"></div>
            <div class="lfcv-lin"><label>Pausa (s)</label><input type="number" id="lfcv-looppausa" min="0" max="30"></div>
            <div class="lfcv-dica">Pula pra um trecho aleatório em vez de rodar o vídeo sempre igual.</div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>🎧 Áudio da live</summary>
          <div>
            <div id="lfcv-audionome" class="lfcv-vazio">Nenhum áudio carregado</div>
            <button class="lfcv-btn sec" id="lfcv-addaudio">+ Carregar áudio</button>
            <input type="file" id="lfcv-audiofile" accept="audio/*" hidden>
            <div class="lfcv-lin"><label>Modo trechos</label><input type="checkbox" id="lfcv-trechos"></div>
            <div class="lfcv-lin"><label>Trecho mín. (s)</label><input type="number" id="lfcv-trmin" min="1" max="120"></div>
            <div class="lfcv-lin"><label>Trecho máx. (s)</label><input type="number" id="lfcv-trmax" min="1" max="300"></div>
            <div class="lfcv-lin"><label>Pausa (s)</label><input type="number" id="lfcv-trpausa" min="0" max="30"></div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>🎙️ Camada ao vivo</summary>
          <div>
            <div class="lfcv-lin"><label>Ativar</label><input type="checkbox" id="lfcv-camada"></div>
            <div class="lfcv-lin"><label>Ruído de sala</label><input type="checkbox" id="lfcv-clruido"></div>
            <div class="lfcv-lin"><label>Respirações</label><input type="checkbox" id="lfcv-clresp"></div>
            <div class="lfcv-lin"><label>Cliques</label><input type="checkbox" id="lfcv-clcliq"></div>
            <div class="lfcv-lin"><label>Variação de mic</label><input type="checkbox" id="lfcv-clvar"></div>
            <div class="lfcv-lin"><label>Volume</label><input type="range" id="lfcv-clvol" min="0" max="0.4" step="0.01"></div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>⚡ Desempenho</summary>
          <div>
            <div class="lfcv-lin"><label>Modo leve (PC fraco)</label><input type="checkbox" id="lfcv-modoleve"></div>
            <div class="lfcv-vazio" style="font-size:11px">Baixa a câmera para 480p/20fps — corta o processamento em PCs fracos (i3) com vídeo longo.</div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>🖼️ Banner</summary>
          <div>
            <div id="lfcv-bannernome" class="lfcv-vazio">Nenhum banner carregado</div>
            <button class="lfcv-btn sec" id="lfcv-addbanner">+ Carregar banner</button>
            <button class="lfcv-btn sec" id="lfcv-delbanner">Remover banner</button>
            <input type="file" id="lfcv-bannerfile" accept="image/*" hidden>
            <div class="lfcv-lin"><label>Escala</label><input type="range" id="lfcv-bnesc" min="0.05" max="1" step="0.01"></div>
            <div class="lfcv-lin"><label>Opacidade</label><input type="range" id="lfcv-bnop" min="0.1" max="1" step="0.01"></div>
            <div class="lfcv-lin"><label>Posição X</label><input type="range" id="lfcv-bnx" min="0" max="100" step="1"></div>
            <div class="lfcv-lin"><label>Posição Y</label><input type="range" id="lfcv-bny" min="0" max="100" step="1"></div>
          </div>
        </details>

        <details class="lfcv-sec">
          <summary>⚙️ Sincronização</summary>
          <div>
            <div class="lfcv-lin"><label>Auto-sync</label><input type="checkbox" id="lfcv-autosync"></div>
            <div class="lfcv-lin"><label>Intervalo (s)</label><input type="number" id="lfcv-syncint" min="10" max="600"></div>
          </div>
        </details>
      </div>`;
    (document.body || document.documentElement).appendChild(raiz);
    corpo = $('lfcv-corpo');
    ligarEventos();
    arrastar();
    restaurarUI();
  }

  function arrastar() {
    const cab = $('lfcv-cab');
    let dx = 0, dy = 0, movendo = false;
    cab.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      movendo = true;
      const r = raiz.getBoundingClientRect();
      dx = e.clientX - r.left; dy = e.clientY - r.top;
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!movendo) return;
      raiz.style.left = Math.max(0, Math.min(innerWidth - 60, e.clientX - dx)) + 'px';
      raiz.style.top = Math.max(0, Math.min(innerHeight - 40, e.clientY - dy)) + 'px';
      raiz.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => { movendo = false; });
  }

  function renderPlaylist() {
    const el = $('lfcv-lista');
    if (!el) return;
    if (!playlist.length) { el.innerHTML = '<div class="lfcv-vazio">Nenhum vídeo carregado</div>'; return; }
    el.innerHTML = playlist.map((p, i) =>
      `<div class="lfcv-item ${i === idxAtual ? 'on' : ''}">
         <span title="${esc(p.nome)}">${i === idxAtual ? '▶ ' : ''}${esc(p.nome)}</span>
         <button data-tocar="${i}" title="Tocar">▶</button>
         <button data-remover="${i}" title="Remover">✕</button>
       </div>`).join('');
    el.querySelectorAll('[data-tocar]').forEach((b) =>
      b.onclick = () => tocar(Number(b.dataset.tocar)));
    el.querySelectorAll('[data-remover]').forEach((b) =>
      b.onclick = () => removerVideo(Number(b.dataset.remover)));
  }

  const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function renderEstado() {
    const b = $('lfcv-toggle');
    if (!b) return;
    if (!liberado) {
      b.textContent = motivoBloqueio === 'login' ? '🔒 Faça login' : '🔒 Assinar plano';
      b.className = 'lfcv-btn off';
      b.onclick = () => {
        if (motivoBloqueio === 'login') { aviso('Abra o Live Fox e faça login.'); return; }
        window.open(urlCheckout, '_blank');
      };
      return;
    }
    b.textContent = ativo ? '⏹ Desligar câmera virtual' : '▶ Ligar câmera virtual';
    b.className = ativo ? 'lfcv-btn' : 'lfcv-btn off';
    b.onclick = () => (ativo ? desligar() : ligar());
  }

  function aplicarMinimizado() {
    if (corpo) corpo.style.display = minimizado ? 'none' : 'block';
    const b = $('lfcv-min');
    if (b) { b.textContent = minimizado ? '+' : '–'; b.title = minimizado ? 'Abrir' : 'Minimizar'; }
  }

  // Repõe nos controles os valores salvos.
  function restaurarUI() {
    const set = (id, prop, v) => { const el = $(id); if (el) el[prop] = v; };
    set('lfcv-loop', 'checked', loopAtivo);
    set('lfcv-loopmin', 'value', loopMin);
    set('lfcv-loopmax', 'value', loopMax);
    set('lfcv-looppausa', 'value', loopPausa);
    set('lfcv-trechos', 'checked', trechosAtivo);
    set('lfcv-trmin', 'value', trMin);
    set('lfcv-trmax', 'value', trMax);
    set('lfcv-trpausa', 'value', trPausa);
    set('lfcv-camada', 'checked', camadaAtiva);
    set('lfcv-clruido', 'checked', clRuido);
    set('lfcv-clresp', 'checked', clRespira);
    set('lfcv-clcliq', 'checked', clCliques);
    set('lfcv-clvar', 'checked', clVariacao);
    set('lfcv-clvol', 'value', clVolume);
    set('lfcv-modoleve', 'checked', modoLeve);
    set('lfcv-bnesc', 'value', bnEscala);
    set('lfcv-bnop', 'value', bnOpacidade);
    set('lfcv-bnx', 'value', bnX);
    set('lfcv-bny', 'value', bnY);
    set('lfcv-autosync', 'checked', autoSync);
    set('lfcv-syncint', 'value', syncSegundos);
    if (audioNome) { const el = $('lfcv-audionome'); if (el) { el.textContent = audioNome; el.className = ''; } }
    if (bannerNome) { const el = $('lfcv-bannernome'); if (el) { el.textContent = bannerNome; el.className = ''; } }
    aplicarMinimizado();
    renderPlaylist(); renderEstado(); renderRecursos();
  }

  function ligarEventos() {
    const on = (id, ev, fn) => { const el = $(id); if (el) el.addEventListener(ev, fn); };
    const num = (id, aplicar) => on(id, 'change', (e) => {
      const v = Number(e.target.value);
      if (Number.isFinite(v)) { aplicar(v); salvarConfig(); }
    });
    const chk = (id, aplicar) => on(id, 'change', (e) => { aplicar(!!e.target.checked); salvarConfig(); });

    on('lfcv-min', 'click', () => { minimizado = !minimizado; aplicarMinimizado(); salvarConfig(); });

    on('lfcv-add', 'click', () => $('lfcv-arquivo').click());
    on('lfcv-arquivo', 'change', (e) => { if (e.target.files.length) addVideos([...e.target.files]); e.target.value = ''; });
    on('lfcv-prev', 'click', () => pular(-10));
    on('lfcv-next', 'click', () => pular(10));
    on('lfcv-sync', 'click', () => ressincronizar(true));

    chk('lfcv-loop', (v) => { loopAtivo = v; if (ativo) { v ? ligarLoopVideo() : pararLoopVideo(); } });
    num('lfcv-loopmin', (v) => loopMin = v);
    num('lfcv-loopmax', (v) => loopMax = v);
    num('lfcv-looppausa', (v) => loopPausa = v);

    on('lfcv-addaudio', 'click', () => $('lfcv-audiofile').click());
    on('lfcv-audiofile', 'change', async (e) => {
      if (!e.target.files.length) return;
      await carregarAudio(e.target.files[0]);
      const el = $('lfcv-audionome'); if (el) { el.textContent = audioNome; el.className = ''; }
      if (ativo) reporTracks();
      e.target.value = '';
    });
    chk('lfcv-trechos', (v) => { trechosAtivo = v; if (engineLigada) ligarAudio(); });
    num('lfcv-trmin', (v) => trMin = v);
    num('lfcv-trmax', (v) => trMax = v);
    num('lfcv-trpausa', (v) => trPausa = v);

    chk('lfcv-camada', (v) => { camadaAtiva = v; if (engineLigada) { v ? ligarCamada() : pararCamada(); } });
    chk('lfcv-clruido', (v) => { clRuido = v; if (camadaAtiva && engineLigada) { pararRuido(); if (v) ligarRuido(); } });
    chk('lfcv-clresp', (v) => { clRespira = v; if (camadaAtiva && engineLigada) { pararRespiracoes(); if (v) ligarRespiracoes(); } });
    chk('lfcv-clcliq', (v) => { clCliques = v; if (camadaAtiva && engineLigada) { pararCliques(); if (v) ligarCliques(); } });
    chk('lfcv-clvar', (v) => { clVariacao = v; if (camadaAtiva && engineLigada) { pararVariacao(); if (v) ligarVariacao(); } });
    chk('lfcv-modoleve', (v) => { modoLeve = v; aplicarQualidade(); salvarConfig(); });
    on('lfcv-clvol', 'input', (e) => { clVolume = Number(e.target.value); atualizarVolumeCamada(); });
    on('lfcv-clvol', 'change', salvarConfig);

    on('lfcv-addbanner', 'click', () => $('lfcv-bannerfile').click());
    on('lfcv-bannerfile', 'change', async (e) => {
      if (!e.target.files.length) return;
      await carregarBanner(e.target.files[0]);
      const el = $('lfcv-bannernome'); if (el) { el.textContent = bannerNome; el.className = ''; }
      e.target.value = '';
    });
    on('lfcv-delbanner', 'click', () => {
      removerBanner();
      const el = $('lfcv-bannernome'); if (el) { el.textContent = 'Nenhum banner carregado'; el.className = 'lfcv-vazio'; }
    });
    const faixa = (id, aplicar) => {
      on(id, 'input', (e) => aplicar(Number(e.target.value)));
      on(id, 'change', salvarConfig);
    };
    faixa('lfcv-bnesc', (v) => bnEscala = v);
    faixa('lfcv-bnop', (v) => bnOpacidade = v);
    faixa('lfcv-bnx', (v) => bnX = v);
    faixa('lfcv-bny', (v) => bnY = v);

    chk('lfcv-autosync', (v) => { autoSync = v; reprogramarSync(); });
    num('lfcv-syncint', (v) => { syncSegundos = v; reprogramarSync(); });
  }

  function pular(seg) {
    if (!videoEl || !videoEl.src || !videoEl.duration) return;
    videoEl.currentTime = Math.min(videoEl.duration, Math.max(0, videoEl.currentTime + seg));
    if (videoEl.paused) videoEl.play().catch(() => {});
  }

  // ======================================================================
  //                     RESTAURAR SESSÃO ANTERIOR
  // ======================================================================
  async function restaurarArquivos() {
    // Vídeos
    const chaves = (await dbTodasChaves('videos')).sort((a, b) => a - b);
    for (const k of chaves) {
      const v = await dbGet('videos', k);
      if (!v || !v.buf) continue;
      playlist.push({ url: URL.createObjectURL(new Blob([v.buf], { type: v.tipo || 'video/mp4' })), nome: v.nome, _buf: v.buf });
    }
    // Áudio
    const a = await dbGet('audio', 'arquivo');
    if (a && a.buf) {
      try {
        iniciarCtx();
        audioBuffer = await audioCtx.decodeAudioData(a.buf.slice(0));
        audioNome = a.nome || 'áudio';
      } catch (e) {}
    }
    // Banner
    const b = await dbGet('banner', 'arquivo');
    if (b && b.buf) {
      const url = URL.createObjectURL(new Blob([b.buf], { type: b.tipo || 'image/png' }));
      await new Promise((resolve) => {
        const img = new Image();
        img.onload = () => { bannerImg = img; bannerNome = b.nome || 'banner'; resolve(); };
        img.onerror = () => resolve();
        img.src = url;
      });
    }
  }

  // ======================================================================
  //                     GATE DE ASSINATURA
  // ======================================================================
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.source !== 'livefox-camera-gate') return;
    const antes = liberado;
    // Offline não derruba quem já está no ar — só bloqueia ligar de novo.
    if (e.data.offline && ativo) return;
    liberado = !!e.data.liberado;
    audioLiberado = !!(e.data.recursos && e.data.recursos.audio_live);
    motivoBloqueio = e.data.motivo || null;
    if (e.data.checkout) urlCheckout = e.data.checkout;
    if (antes && !liberado && ativo) { desligar(); aviso('🔒 Assinatura encerrada — câmera desligada.'); }
    renderEstado(); renderRecursos();
    if (liberado && !antes) aviso('Pronto. Adicione um vídeo e ligue a câmera virtual.');
  });

  // ======================================================================
  //                     BOOT
  // ======================================================================
  async function iniciar() {
    await carregarConfig();
    montarUI();
    await restaurarArquivos();
    restaurarUI();
    reprogramarSync();
    if (!liberado) travaAssinatura();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar, { once: true });
  } else {
    iniciar();
  }
})();
